$(document) .ready(function(){
$("#teacher_access").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "t-access.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#t-access") .html(data);
			

		}

})


})
$("#delete_result").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "delete_result.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#DelResult") .html(data);
			

		}

	})
})

	$("#check_result").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "check_result1.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#CheckResult") .html(data);
			

		}

})
})

$("#edit_result").click(function(event){
	alert(0);
	event.preventDefault();
		$.ajax({
			url : "edit_result1.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#EditResult") .html(data);
			

		}

})
})

view_teacher();
function view_teacher(){
		$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {viewTeacher:1},
			success : function(data){
			$("#ViewTeacher").html(data);
			}
		})
	}

	$("body").delegate(".inbox","click",function(event){
	event.preventDefault();
	
	var pid = $(this).attr("inbox_id");
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {InboxMessage:1,inboxId:pid},
			success : function(data){
			$("#responseMsg").html(data);
			


	}

})

})
	view_result2();
function view_result2(){
		$.ajax({
			url : "generate_eng.php",
			method: "POST",
			data   :  {viewResult2:1},
			success : function(data){
			$("#ViewGenerateMsg1").html(data);
			}
		})
	}
})