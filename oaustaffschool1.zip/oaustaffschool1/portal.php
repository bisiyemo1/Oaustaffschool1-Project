<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OAU STAFF SCHOOL</title>
    <link href="home/css/bootstrap.min.css" rel="stylesheet">
	<link href="CustomStyleHome.css" rel="stylesheet" />

	<style type="text/css">
		
		body{ position: relative; }

	</style>

  </head>

  <body data-spy="scroll" data-target="#mainNavbar" data-offset="10">

					<!--Code for navigation bar and Header-->
					
					<nav id="mainNavbar" >  

					<!--Code for header only-->
							
						
							<div class="row">
								<div class="col-xs-12">

									<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
										<div class="panel-heading">
										
											<div id="customDiv2">
												<img class="img-responsive" src="images/schoollogo.jpg">
											</div>
										
										
											<h3 class="panel-title">OBAFEMI AWOLOWO UNIVERSITY STAFF SCHOOL<h3>
											
										</div>
							
									</div>
								</div>
							</div>
				
									
					<!--Code for Navigation bar using breadcrumb-->
														
									<div class="row">
										<div class="col-xs-12">
													<!--NOTE: The forward slash "/" of the breadcrumb is changed to vertical slash"|". The background color or other things, can also be changed to your desire color(yellow)-->
							
												<ol class="breadcrumb">
														<li><a href="index.php">Home</a></li>
														<li><a href="about.php">About</a></li>
														<li><a href="contact.php">Contact</a></li>
														<li class="active"><a href="portal.php">Portal</a></li>
												</ol>

										</div>
									</div>
															
					</nav> 

		<!--code for LOGIN TO CHECK RESULTS -->
	

			<div class="container">
				<div class="row">
					<div class="col-xs-12">

									
							<!--To change the background colour, go to css to declare ".well{backgroud-color: #DDDF7C;}"-->
						<div class="well">	
							<h3>LOGIN TO CHECK RESULTS</h3>
							<hr />
								<form class="form-horizontal">
									<div class="form-group">
										<label for="inputUsername" class="control-label col-sm-2">Username</label>
										<div class="col-sm-10">
											<input class="form-control" type="text" id="inputUserName" placeholder="Login Username"/>
										</div>
									</div>
									<div class="form-group">
										<label for="inputPassword" class="control-label col-sm-2">Passsword</label>
										<div class="col-sm-10">
											<input class="form-control" type="password" id="inputPassword" placeholder="Login Passsword"/>
										</div>
									</div>
									<div class="form-group">
										<div class="col-sm-offset-2 col-sm-10">
											<button class="btn btn-default" type="submit">Login</button>
										</div>
									</div>
							
								</form>
						</div>
						
						
				<!--code for LOGIN FOR MESSAGES -->
						
						<div class="well">	
							<h3>LOGIN FOR MESSAGES</h3>
							<hr />
								<form class="form-horizontal">
									<div class="form-group">
										<label for="inputUsername" class="control-label col-sm-2">Username</label>
										<div class="col-sm-10">
											<input class="form-control" type="text" id="inputUserName" placeholder="Login Username"/>
										</div>
									</div>
									<div class="form-group">
										<label for="inputPassword" class="control-label col-sm-2">Passsword</label>
										<div class="col-sm-10">
											<input class="form-control" type="password" id="inputPassword" placeholder="Login Passsword"/>
										</div>
									</div>
									<div class="form-group">
										<div class="col-sm-offset-2 col-sm-10">
											<button class="btn btn-default" type="submit">Login</button>
										</div>
									</div>
							
								</form>
						</div>
						
						
  					</div>
				</div>
			</div>	







			
	<!-- For footer -->

		<div id="footer"> 

			<div id="copyright">
				&copy; Copyright 2017 by OAU STAFF SCHOOL. All right reserved.
			</div>
	
			<div id="sociallink">
		
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" /></a>
				<a href="http://www.yahoomail.com"><img src="images/email.jpg" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" /></a>
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" /></a>
			</div>
	
		</div>






















			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>

			<script type="text/javascript">
  					/*Javascript for Picture slide show*/
  				$(document).ready(function () {
  					$('#imageCarousel').carousel();
  				});
  			</script>


    </body>
</html>