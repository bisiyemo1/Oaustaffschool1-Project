<?php
require_once("connection.php");
if($_SESSION['user_role'] != "Administrator")
{

header("location: logout.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  
 <head>
    <meta charset="utf-8">
    <title>Add Teacher Account - OAU STAFF SCHOOL</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
<link href="css/style.css" rel="stylesheet" type="text/css">

<link href="css/pages/signin.css" rel="stylesheet" type="text/css">
<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.js"></script>
	 <script src="teacher.js"></script>
       
</head>

<body>
	
	<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<a class="brand" href="index.html">
				Obafemi Awolowo University Staff School				
			</a>		
			
			<div class="nav-collapse">
				<ul class="nav pull-right">
					<li class="">						
						<a href="t-panel.php" class="">
							Back to Dashboard
						</a>
						
					</li>
					<li class="">						
						<a href="logout.php" class="">
							<i class="icon-chevron-left"></i>
							Logout
						</a>
						
					</li>
				</ul>
				
			</div><!--/.nav-collapse -->	
	
		</div> <!-- /container -->
		

	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->


<?php include "menu.php";   ?>
<div class="account-container register">
	
	<div class="content clearfix" >

		<div id="t-access"></div>
		
		
		
		<form action="#" method="post" id="myform" enctype="multipart/form-data">
		
			<h1>Create Teacher Access Details</h1>			
			
			<div class="login-fields">
				<div class="field">
					<label for="firstname">Teacher's Name</label>
					<input type="text" id="t_name" name="t_name" placeholder="Teacher's Name" class="username" />
				</div> <!-- /field -->	
				<div class="field">
					<label for="firstname">Class</label>
					<select class="class" name="class" style="width:100%;" id="class">
						<option value="">Select Class</option>
						<?php  

					//this section display the data in the database into the input box in the forms below

							

								$sql = "SELECT * FROM class ";
								$run_sql = mysqli_query($con,$sql);

								while($row=mysqli_fetch_array($run_sql)){
						
								$name = $row["name"];
								

								

						echo "<option value='$name'>$name</option>";

						}

			 		?>
					 	
				</div> <!-- /field -->
			<div class="field">
					<label for="firstname">Email</label>
					<input type="text" id="username" name="email" placeholder="Email" class="username" />
				</div> <!-- /field -->
				
				
				<div class="field">
					<label for="lastname">Password</label>	
					<input type="text" id="password" name="password" placeholder="Password" class="login" />
				</div> <!-- /field -->
								
				<br />
				<div class="field">
					<label for="phone">Phone Number</label>	
					<input type="text" id="phone" name="phone" placeholder="Phone Number" class="login" />
				</div> <!-- /field -->
				<div class="field">
					<select class="username" name="sex" style="width:100%;">
						<option value="">Select Teacher Gender</option>
					<option value="male">Male</option>	
					<option value="female">Female</option>
					</select>
				</div> <!-- /field -->
				<input type="submit" style="width:100%;" class="button btn btn-success btn-large" name="teacher_access" id="teacher_access" value="Create">
				
			</div> <!-- .actions -->

					</div>
				
			</div> <!-- /login-fields -->
			
			
			
		</form>
		
	</div> <!-- /content -->
	
</div> <!-- /account-container -->

<script type="text/javascript">
 
</script>
<!-- Text Under Box -->


<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

</body>

 </html>
