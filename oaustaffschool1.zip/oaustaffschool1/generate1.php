<?php

include "connection.php";


$student_name = $_POST['student_name'];
$_SESSION['student_name'] = $student_name;


if((!$student_name)){


	echo "<div style='color:red;'>The fields cannot be left empty</div>";
}
	
	else{


		echo " <script type=\"text/javascript\">
						window.location='generate2.php'</script>";

	}



	

?>