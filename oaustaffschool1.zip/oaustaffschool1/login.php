
<?php require_once "login_action.php";  ?>
<!DOCTYPE html>
<html lang="en">
  
 <head>
    <meta charset="utf-8">
    <title>Signin - OAU STAFF SCHOOL</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

	<link href="css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/pages/signin.css" rel="stylesheet" type="text/css">

	<link href="CustomStyleHome.css" rel="stylesheet" />

</head>

<body>

	<!--Code for navigation bar and Header-->
	
	<nav id="mainNavbar" >  

					<!--Code for header only-->
							
						
							<div class="row">
								<div class="col-xs-12">

									<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
										<div class="panel-heading">
										
											<div id="customDiv2">
												<img class="img-responsive" src="images/schoollogo.jpg">
											</div>
										
										
											<h3 class="panel-title">OBAFEMI AWOLOWO UNIVERSITY STAFF SCHOOL<h3>
											
										</div>
							
									</div>
								</div>
							</div>
				
									
					<!--Code for Navigation bar using breadcrumb-->
														
									<div class="row">
										<div class="col-xs-12">
													<!--NOTE: The forward slash "/" of the breadcrumb is changed to vertical slash"|". The background color or other things, can also be changed to your desire color(yellow)-->
							
												<ol class="breadcrumb">
														<li class="active"><a href="index.php">Home</a></li>
														<li class="active">/<a href="about.php">About</a></li>
														<li class="active">/<a href="login.php">Portal</a></li>
														 <ul class="nav pull-right active">	
														     <li class="">						
															     <a href="index.php" class="">
																     Logout
													       		</a>
														     </li>
													    </ul>
												</ol>

										</div>
									</div>
															
					</nav>



<div class="account-container register">
	
	<div class="content clearfix">
		
		<div style="color:red;"><?php echo $error; ?>  </div>
		<div style="color:red;"><?php echo $msg; ?>  </div>
		
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" id="myform">
		
			<h1>Sign In  Here</h1>			
			
			<div class="login-fields">
				
				<p>Login Panel - OAU STAFF SCHOOL</p>
				
				
				<div class="field">
					<label for="lastname">Username:</label>	
					<input type="text" id="username" name="username" value="" placeholder="Username" class="login" />
				</div> <!-- /field -->
			<div class="field">
					<label for="password">Password:</label>
					<input type="password" id="password" name="password"  placeholder="Password" class="login"/>
				</div> <!-- /field -->
				<div>
					<label>Term</label>
					<select name="term" style="width:100%;">
					 	<option value="">Select Term</option>
						<option value="1st">First</option>
						<option value="2nd">Second</option>
						<option value="3rd">Third</option>


					</select>
				</div>
				<div>
					<label>Session</label>
					<select name="session" style="width:100%;">
					 	<option value="">Select Session</option>
						<option value="2016/2017">2016/2017</option>
						<option value="2017/2018">2017/2018</option>


					</select>
				</div>
				<div class="btn">
									
				<input type="submit" class="button btn btn-success btn-large" name="login" value="Login">
				
			</div> <!-- .actions -->

			</div>		
		
		</form>
		
	</div> <!-- /content -->
	
</div> <!-- /account-container -->	

<script type="text/javascript">
 var frmvalidator = new Validator("myform"); 
 frmvalidator.addValidation("firstname","req","Please enter student firstname"); 
 frmvalidator.addValidation("firstname","maxlen=50");
 frmvalidator.addValidation("lastname","req","Please enter student lastname"); 
 frmvalidator.addValidation("lastname","maxlen=50");d
 frmvalidator.addValidation("username","req","Please enter student username"); 
 frmvalidator.addValidation("username","maxlen=50");
 frmvalidator.addValidation("password","req","Please enter student password"); 
 frmvalidator.addValidation("password","minlen=6","Password must not be less than 6 characters.");
 frmvalidator.addValidation("phone","req","Please enter student Phone Number"); 
 frmvalidator.addValidation("phone","dontselect=000","You fill your phone number");
 frmvalidator.addValidation("stud_id","req","Please enter your Matric number"); 
 frmvalidator.addValidation("stud_id","maxlen=50");
 frmvalidator.addValidation("yos","req","Please enter year of study"); 
 frmvalidator.addValidation("yos","dontselect=000","You don't select Year Of study");
</script>
<!-- Text Under Box -->
<div class="login-extra btn-success">
	 <a href="recovery.php">Forget Password?</a>
	 <a href="resetpwd.php">Enter Reset Code</a>
</div> <!-- /login-extra -->
<div class="login-extra btn-success">
	<center>
		Return to  <a href="register.php">Register Here</a>
	</center>
</div> <!-- /login-extra -->

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

</body>

 </html>
