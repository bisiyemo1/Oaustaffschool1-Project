<?php

include "connection.php";

$parent_name = $_POST['p_name'];
$username = $_POST['email'];
$password = $_POST['password'];
$password2 = $_POST['password'];
$student_name = $_POST['stu_name'];
$class = $_POST['class'];
$phone = $_POST['phone'];
$sex = $_POST['sex'];
$user_role = "Parent";
$date = date("Y-m-d");
if((!$parent_name)  || (!$username) || (!$password) || (!$student_name) || (!$class) || (!$sex) || (!$phone)){


	echo "<div style='color:red;'>The fields cannot be left empty</div>";
}
	
	else{


	$sql = "SELECT * FROM student_record where email= '$username' or student_name = '$student_name'";
	$run_sql = mysqli_query($con, $sql);
	$count = mysqli_num_rows($run_sql);

	if($count > 0 ){

		echo  "<script type=\"text/javascript\">alert('$username Details Already Found in the System');
						</script>";

	}else{

			$password = md5($password);
			$sql = "INSERT INTO student_record(student_name,sex,class,email,phone,parent_name,date_added,status) 
			VALUES('$student_name','$sex','$class','$username','$phone','$parent_name','$date','ACTIVE')";
			if(mysqli_query($con, $sql)){

				mysqli_query($con, "INSERT INTO user(username,password,user_role,status,name,student_name,phone,password2)
				 values('$username','$password','Parent','ACTIVE','$parent_name','$student_name','$phone','$password2')");

				echo  "<script type=\"text/javascript\">alert('$parent_name Details entered Successfully');
						</script>";


			}else{


				echo  "<script type=\"text/javascript\">alert('$parent_name Details NOT Successfully Added');
						</script>";

			}



	}

}

?>