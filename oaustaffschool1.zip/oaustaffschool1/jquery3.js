$ (document) .ready(function(){

$("#myupload").on('submit', function(event){
	event.preventDefault();
		$.ajax({

			url : "upload_student_record.php",
			method: "POST",
			data   :  new FormData(this),
			contentType:false,
			cache:false,
			processData: false,
			success : function(data){

			if(data == "Error1"){

				alert("Invalid File Input");

			}else if(data == "Error2"){

				alert("please select file");
			}
			else if(data == "Error3"){

				alert("Student is Already Added");
			}
			else{
				$("#UploadMsg") .html(data);

			}
			


		}

	})

})

$("#resultupload").on('submit', function(event){
	event.preventDefault();
		$.ajax({

			url : "upload-result1.php",
			method: "POST",
			data   :  new FormData(this),
			contentType:false,
			cache:false,
			processData: false,
			success : function(data){
			$("#UploadResultMsg") .html(data);

		}	

	})

})


view_student();
function view_student(){
		$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {viewStudent:1},
			success : function(data){
			$("#ViewStudentMsg").html(data);
			}
		})
	}

$("body").delegate(".update","click",function(event){

	event.preventDefault();
	
	var pid = $(this).attr("update_id");
	var id = $("#id-"+pid).val();
	var status = $("#status-"+pid).val();
	
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {updateStudentStatus:1,updateId:pid,id:id,status:status},
			success : function(data){
			$("#updateStudentMsg").html(data);
			view_student();


	}

})

})
$("body").delegate(".remove","click",function(event){

	event.preventDefault();
	var pid = $(this).attr("remove_id");
	
	
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {removeStudent:1,removeId:pid},
			success : function(data){
			$("#removeStudentMsg").html(data);
			view_student();


	}

})

})

$("#parent_access").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "p-access.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#parentAccessMsg") .html(data);
			

		}

})


})

view_student_details();
function view_student_details(){
		$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {viewStudentDetail:1},
			success : function(data){
			$("#ViewStudentDetailMsg").html(data);
			}
		})
	}
	
$("body").delegate(".deleteInbox","click",function(event){
	event.preventDefault();
	var pid = $(this).attr("delete_id");

	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {removeInboxMsg:1,removeId:pid},
			success : function(data){
			$("#responseMsg").html(data);
			compose();
		


	}

})

})			


})