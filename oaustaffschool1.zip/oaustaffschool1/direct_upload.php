<?php

include "connection.php";

$subject = $_POST['subject'];
$class = $_POST['class'];
$test = $_POST['test'];
$exam = $_POST['exam'];
$student_name = $_POST['st_name'];
$term = $_SESSION['term'];
$session = $_SESSION['session'];

if((!$subject)  || (!$class) || (!$test) || (!$exam) || (!$student_name)){


	
}
	
	else{


	$sql = "SELECT * FROM student_result where student_name= '$student_name' and term = '$term' and session='$session'";
	$run_sql = mysqli_query($con, $sql);
	$count = mysqli_num_rows($run_sql);

	if($count > 0 ){

		
		echo "<div style='color:red;'>Result Already uploaded for this $term term and $session Session</div>";				

	}else{

			
			$sql = "INSERT INTO student_result(student_name,class,subject,exam_score,test_score,term,session) 
			VALUES('$student_name','$class','$subject','$exam','$test','$term','$session')";
			if(mysqli_query($con, $sql)){

			

				echo "<div style='color:green;'>Result Uploaded Successfully for $student_name</div>";


			}else{


				echo  "<script type=\"text/javascript\">alert('NOT Successfully');
						</script>";

			}



	}

}

?>