<?php
session_start();
unset($_SESSION['username']);
unset($_SESSION['password']);
unset($_SESSION['user_role']);
unset($_SESSION['code']);
session_destroy();

header('Location: login.php');
?>