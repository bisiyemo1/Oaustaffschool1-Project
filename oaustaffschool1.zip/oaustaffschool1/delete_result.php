<?php

include "connection.php";

$subject = $_POST['subject'];


if(!$subject){


	echo "Please select a subject";

}else{

		$sql = "SELECT * FROM student_result where subject='$subject' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
		$run_sql = mysqli_query($con, $sql);
		$count = mysqli_num_rows($run_sql);

		if($count == 0 ){

			echo  "<script type=\"text/javascript\">alert('Result Not Found in the System');
						</script>";

		}else{



		$sql = "DELETE FROM student_result where subject='$subject' and class='$_SESSION[class]' and session='$_SESSION[session]' 
		and term='$_SESSION[term]' ";

		if(mysqli_query($con, $sql)){


			echo  "<script type=\"text/javascript\">alert('Result Deleted Successfully');
						</script>";
		}else{


			echo "Operation not Successful";
		}

	}

}





?>