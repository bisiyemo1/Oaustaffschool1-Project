<?php
include "connection.php";
$msg = "";
$error  = "";
$level  = "";
$username =  "";


if(isset($_POST['login'])){
$username = $_POST['username'];
$password   = $_POST['password'];
$term = $_POST['term'];
$session = $_POST['session'];


if((!$password) || (!$username) || (!$term) || (!$session)){

  $error=   "Please fill empty fields";

}else{
  
  //Adding the escape character
  $password = addslashes($password);
  $username = addslashes($username);
  
  
   // Error handling is complete so process the customer if no errors
    
    $password = mysqli_real_escape_string($con,$password); // After we connect, we secure the string before adding to query
      //$password = mysqli_real_escape_string($password); // After we connect, we secure the string before adding to query
    $username = mysqli_real_escape_string($con,$username); // Add MD5 Hash to the passwordword variable they supplied after filtering it
    // Make the SQL query
    
        $password = md5($password);
        $sql = "SELECT * FROM user WHERE username='$username' AND password='$password'"; 
        $run_sql = mysqli_query($con,$sql);
      $login_check = mysqli_num_rows($run_sql);
        // If login check number is greater than 0 (meaning they do exist and are activated)
    if($login_check > 0){ 
          while($row = mysqli_fetch_array($run_sql)){
          
          
          // Create session var for their raw status
          $username = $row["username"]; 
          $user_role = $row["user_role"];    
          $_SESSION['username'] = $username;
          // Create session var for their username, password, user_role and status
           $password = $row["password"]; 
          $_SESSION['password'] = $password;
           $user_role = $row["user_role"];    
          $_SESSION['user_role'] = $user_role;
           $status = $row["status"];    
          $_SESSION['status'] = $status;
          $name = $row["name"];
          $_SESSION['name'] = $name;
          $_SESSION['term'] = $term;
          $_SESSION['session'] = $session;
          $phone_no = $row['phone'];
          $_SESSION['phone_no'] = $phone_no;

          if($user_role == "Teacher" && $status == "ACTIVE"){

            $class = $row["class"];
            $_SESSION['class'] = $class;

          header("Location: t-panel.php");

         }
         if($user_role == "Administrator" && $status == "ACTIVE"){

            $subject = $row["subject"];
            $_SESSION['subject'] = $subject;

          header("Location: administrator.php");

         }

         if($user_role == "Parent" && $status == "ACTIVE"){

               $stu_name = $row["student_name"];
               $_SESSION['student_name'] = $stu_name;

              $sql = "SELECT * FROM student_result where student_name = '$_SESSION[student_name]' and session ='$session' and term = '$term' ";
                    $run_sql = mysqli_query($con,$sql);

                    while($row=mysqli_fetch_array($run_sql)){
                
                    $class = $row["class"];
                    $_SESSION["class"] = $class;

                  }

              header("Location: p-panel.php");

         }

       }

        }else{

          $error = "<div style='color:red;'>Wrong information supplied</div>";
        }

       }
}
   
  
?>
<?php
$msg = "";
if(isset($_POST['register'])){

  $username = $_POST['username'];
  $password   = $_POST['password'];
  $c_password   = $_POST['c_password'];
  $password2 = $_POST['password'];


  if((!$password) || (!$username)){

    $error=   "Please fill empty fields";

}
if($c_password != $password){

    $error=   "Your Password do not match";

}else{

      $sql = "SELECT * FROM user WHERE username='$username'"; 
        $run_sql = mysqli_query($con,$sql);
      $login_check = mysqli_num_rows($run_sql);
        // check if the parent has already registered
    if($login_check > 0){ 


        $msg = "Your Email has already been registered";


      }else{
        

      $sql = "SELECT * FROM student_record WHERE email='$username'"; 
      $run_sql = mysqli_query($con,$sql);
      $login_check = mysqli_num_rows($run_sql);
        // If login check number is greater than 0 (meaning they do exist and are activated)
    if($login_check > 0){ 

      $password = md5($password);

      $user_role = "Parent";

      while($row=mysqli_fetch_array($run_sql)){

        $parent_name = $row["parent_name"];
        $student_name = $row["student_name"];
        $phone = $row["phone"];
       
      }
      $insert = "INSERT INTO user (username,password,user_role,name,password2,phone) values('$username','$password','$user_role','$parent_name','$password2','$phone')";
      if(mysqli_query($con,$insert)){


        echo " <script type=\"text/javascript\">alert('Registration Successful. Please Login');
            </script>";
      }

    }
    else{

      $msg = "Your Email could not be found in the system";

    }

}

}
}
?>
<?php
if(isset($_POST['recovery'])){

  $username = $_POST['username'];
  $code = rand(0000,9999);
  $date_sent = date("Y-m-d");

if(!$username){

  $error = "Please enter your Email";

}else{

      $sql = "SELECT * FROM user WHERE username='$username'"; 
        $run_sql = mysqli_query($con,$sql);
      $login_check = mysqli_num_rows($run_sql);
        // check if the parent has already registered

       while($row=mysqli_fetch_array($run_sql)){

        $parent_name = $row["name"];
        $phone = $row["phone"];

      }
    if($login_check > 0){ 


          $sql = "INSERT INTO recovery_pass (username,code,sent_date) values('$username','$code','$date_sent')";

          if(mysqli_query($con,$sql)){

            $sms = '<iframe src="http://api.smartsmssolutions.com/smsapi.php?username=oaustaffschool&password=oaustaffschool&sender=OauStaffSch&recipient='.$phone.'&message=Dear '.$parent_name.', your password reset code is '.$code.' and valid till 11:59PM today. Thanks"</iframe>';

            echo "<center>

              <div style='color:green;'> Password Reset Code Sent successfuly to $parent_name  </div>
              <a href='resetpwd.php'>Proceed to Reset Password</a>
              <div>$sms </div>
              </center>";

          }



      }else{

        $error = "Your Email not registered or not found in our system";

      }

    }

  }



if(isset($_POST['codesent'])){

  $code = $_POST['code'];
  $date_sent = date("Y-m-d");

if(!$code){

  $error = "Please enter your 4-digit Code Only";

}else{

      $sql = "SELECT * FROM recovery_pass WHERE code='$code' and sent_date='$date_sent' and status=0 "; 
        $run_sql = mysqli_query($con,$sql);
      $login_check = mysqli_num_rows($run_sql);
        // check if the parent has already registered
if($login_check > 0){ 

      $_SESSION['code'] = $code;

      echo " <script type=\"text/javascript\">alert('Code Accepted');
            window.location='resetpwd2.php'</script>";


}else{

  $error = "Sorry, Your Code is Incorrect or has expired";
}

}


}



if(isset($_POST['resetpwd'])){

  $password = $_POST['password'];
  $password2 = $_POST['password'];
  $c_password = $_POST['c_password'];


  if((!$password) || ($c_password)){

    $error = "Please enter both fields";


  }if($password!=$c_password){


    $error = "Your Password do not match. please check and try again";
  }
  else{

         $sql = "SELECT * FROM recovery_pass WHERE code='$_SESSION[code]'"; 
            $run_sql = mysqli_query($con,$sql);
          $login_check = mysqli_num_rows($run_sql);
            // check if the parent has already registered

           while($row=mysqli_fetch_array($run_sql)){

            $username = $row["username"];
           

          }

        $password = md5($password);
        $update = "UPDATE user SET password='$password', password2='$password2' where username='$username'";

        if(mysqli_query($con,$update)){


           mysqli_query($con, "UPDATE recovery_pass SET status=1 where code='$_SESSION[code]'");
           echo " <script type=\"text/javascript\">alert('Password Successfully Reset. Redirecting to Login');
            window.location='logout.php'</script>";

        }else{

          $error ="Sorry, an error has occurred";

        }




  }
  
}


?>

