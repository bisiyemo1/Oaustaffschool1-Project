<?php
require_once("connection.php");
if($_SESSION['user_role'] != "Administrator")
{

header("location: logout.php");
}
?>
<!DOCTYPE html>
<html lang="en">  
<head>
    <meta charset="utf-8">
    <title>Promote Students - OAU STAFF SCHOOL</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    
    <link href="css/style.css" rel="stylesheet">
    
    
    <link href="js/guidely/guidely.css" rel="stylesheet"> 
    <link href="css/pages/plans.css" rel="stylesheet"> 
    <link href="js/jquery-ui.css" rel="stylesheet"> 
    <link href="css/pages/signin.css" rel="stylesheet"> 
    <link href="css/pages/dashboard.css" rel="stylesheet"> 

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.js"></script>
        <script src="main.js"></script>
        <script src="promote.js"></script>
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
  </head>

<body>

<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<a class="brand" href="administrator.php">
				OAU STAFF SCHOOL 				
			</a>		
			
				
	
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->

    
<?php include "menu.php";   ?>
    
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	
	      <div class="row">	 

	      	<div class="span6">
	      		
	      		<div class="widget">
	      			
	      			<div class="widget-content">
	      				
			      		<h1>Promotion Center</h1>
			      		
			      		<p></p>	
			      		
		      		</div> <!-- /widget-content -->
		      		
	      		</div> <!-- /widget -->
	      		
      		</div> <!-- /span6 -->
      		 	
	      	
	      	<div class="span6">
	      		
	      		<div id="target-2" class="widget">
	      			
	      			<div class="widget-content">
	      				
			      		<h3 id=""></h3>
			      		
			      		<p></p>	
			      		
		      		</div> <!-- /widget-content -->
		      		
	      		</div> <!-- /widget -->
	      		
      		</div> <!-- /span6 -->   
      		</div>  	
	     

<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	
	      <div class="row">
	      	
	      	<div class="span12">
	      		<center>
	      		<div class="widget">
						
					<div class="widget-header">
						<i class="icon-th-large"></i>
						<h3>Promote Students</h3>  
					</div> <!-- /widget-header -->
					<div>
						<br>
						<div style="color:red;" id="DelResult"></div>
						<hr>
						<form action="#" method="post" id="myform" enctype="multipart/form-data">
						<div class="login-fields">		
				
				
			
				<div>
					<label>Promotion From</label>
					<select name="from" style="width:28%;">
						<option value="">Promotion To</option>
					<?php  

					//this section display the data in the database into the input box in the forms below

							

								$sql = "SELECT * FROM class";
								$run_sql = mysqli_query($con,$sql);

								while($row=mysqli_fetch_array($run_sql)){
						
								$name = $row["name"];
								

								

						echo "<option value='$name'>$name</option>";

						}
						echo "<option value='$_SESSION[session]'>Graduated in ($_SESSION[session])</option>";

			 		?>
					 	


				
					</select>
				</div>
				<div>
				<label>Promoted To</label>
					<select name="to" style="width:28%;">
						<option value="">Promoted To</option>
					<?php  

					//this section display the data in the database into the input box in the forms below

							

								$sql = "SELECT * FROM class";
								$run_sql = mysqli_query($con,$sql);

								while($row=mysqli_fetch_array($run_sql)){
						
								$name = $row["name"];
								

								

						echo "<option value='$name'>$name</option>";

						}
						echo "<option value='$_SESSION[session]'>Graduated in ($_SESSION[session])</option>";
			 		?>
					 	


				
					</select>
				</div>
				<input type="submit" style="width:100%;" class="button btn btn-success btn-large" name="promote_to" id="promote_to" value="Promote">
				
						</center>
					</div>
					<div>
						
					</div>
						<div id="PromoteMsg"> </div>
						
									
								</div>
								</div> <!-- /widget-content -->
						
								</div> <!-- /widget -->
										
						    </div> <!-- /span12 -->     	
					      	
					      	
					      </div> <!-- /row -->
					
					    </div> <!-- /container -->
					    
					</div> <!-- /main-inner -->
				    
				</div> <!-- /main -->
    	      	</div>

	      </div>
	  </div>

<div class="extra">

	<div class="extra-inner">

		<div class="container">


		</div> <!-- /container -->

	</div> <!-- /extra-inner -->

</div> <!-- /extra -->  
<div class="footer">
	
	<div class="footer-inner">
		
		<div class="container">
			
			<div class="row">
				
    			<div class="span12">
    				&copy; <?php echo date('Y');   ?><a href="#">  Obafemi Awolowo University Staff School</a>.
    			</div> <!-- /span12 -->
    			
    		</div> <!-- /row -->
    		
		</div> <!-- /container -->
		
	</div> <!-- /footer-inner -->
	
</div> <!-- /footer -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.7.2.min.js"></script>

<script src="js/bootstrap.js"></script>
<script src="js/base.js"></script>

<script src="js/guidely/guidely.min.js"></script>

<script>



</script>
  </body>

</html>
