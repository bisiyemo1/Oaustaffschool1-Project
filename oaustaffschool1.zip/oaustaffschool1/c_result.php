<?php

include "connection.php";

$class = $_POST['class'];
$student_name = $_POST['st_name'];
$term = $_SESSION['term'];
$session = $_SESSION['session'];

if((!$class) ||  (!$student_name)){


	echo "<div style='color:red;'>The fields cannot be left empty</div>";
}
	
	else{


	$sql = "SELECT * FROM student_result where student_name= '$student_name' and term = '$term' and session='$session' and class='$class' ";
	$run_sql = mysqli_query($con, $sql);
	$count = mysqli_num_rows($run_sql);

	if($count > 0 ){

		$_SESSION['class'] = $class; 
		 $_SESSION['student_name'] = $student_name;

		echo " <script type=\"text/javascript\">
						window.location='view_result.php'</script>";

	}else{


				echo "<div style='color:red;'>No Result Found or Result yet to be uploaded by the Teachers</div>";

			}



	}

?>