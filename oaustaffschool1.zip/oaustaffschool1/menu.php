<div class="subnavbar">

	<div class="subnavbar-inner">
	
		<div class="container">

			<ul class="mainnav">
			
				<li>
					<?php 

					if($_SESSION["user_role"] == "Teacher"){

						echo '<a href="t-panel.php">
						<i class="icon-dashboard"></i>
						<span>Dashboard</span>
					</a>';


					}else if($_SESSION["user_role"] == "Parent"){


						echo '<a href="p-panel.php">
						<i class="icon-dashboard"></i>
						<span>Dashboard</span>
					</a>';

					}else if($_SESSION["user_role"] == "Administrator"){


						echo '<a href="administrator.php">
						<i class="icon-dashboard"></i>
						<span>Dashboard</span>
					</a>';

					}
					?>

						    				
				</li>
				<?php 

				if($_SESSION["user_role"] == "Teacher"){

					?>

				
				
				<li class="">
					<a href="messages.php">
						<i class="icon-list-alt"></i>
						<span>Message Center</span>
					</a>    				
				</li>
				
				<li >					
					<a href="upload-result.php">
						<i class="icon-facetime-video"></i>
						<span>Upload Results</span>
					</a>  									
				</li>
				<li >					
					<a href="generate_report.php">
						<i class="icon-facetime-video"></i>
						<span>Check Results</span>
					</a>  									
				</li>
				<?php }  ?>
				<?php 

				if($_SESSION["user_role"] == "Parent"){

					?>
				<li class="">
					<a href="check-result.php">
						<i class="icon-list-alt"></i>
						<span>Check Result</span>
					</a>    				
				</li>
				<li class="">
					<a href="messages.php">
						<i class="icon-list-alt"></i>
						<span>Message Center</span>
					</a>    				
				</li>
				<?php }  ?>
				<?php 

				if($_SESSION["user_role"] == "Adminstrator"){

					?>
					<li class="">
					<a href="add-student.php">
						<i class="icon-list-alt"></i>
						<span>Upload Student/Parent Records</span>
					</a>    				
				</li>
				<li class="">
					<a href="create-parent-account.php">
						<i class="icon-list-alt"></i>
						<span>Create Parent Access</span>
					</a>    				
				</li>
				<li class="">
					<a href="create-parent-account.php">
						<i class="icon-list-alt"></i>
						<span>Create Teachers' Access</span>
					</a>    				
				</li>
				<?php }  ?>
				 <li>					
					<a href="logout.php">
						<i class="icon-bar-chart"></i>
						<span>Logout</span>
					</a>  									
				</li>
             		
			</ul>

		</div> <!-- /container -->
	
	</div> <!-- /subnavbar-inner -->

</div> <!-- /subnavbar -->
    