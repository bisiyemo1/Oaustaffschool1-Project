$(document) .ready(function(){
$("body").delegate(".DeleteSent","click",function(event){

	event.preventDefault();
	var pid = $(this).attr("delete_id");

	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {removeSentMsg:1,removeId:pid},
			success : function(data){
			$("#responseMsg").html(data);
		
		


	}

})

})
$("#teacher_access").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "t-access.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#t-access") .html(data);
			

		}

})


})




})