<?php

include "connection.php";

$subject = $_POST['subject'];



if(!$subject) {


	echo  "<script type=\"text/javascript\">alert('Please fill all the field');
						</script>";

			}
			

			else{
				$no = 0;
				$select = "SELECT * FROM student_result where term='$_SESSION[term]' and session='$_SESSION[session]' and subject='$subject' and class='$_SESSION[class]' ";
				$result = mysqli_query($con, $select);

				$count = mysqli_num_rows($result);

					if($count == 0 ){

		
				echo "<script type=\"text/javascript\">alert('No $subject result found for $_SESSION[class] in the session selected');
						</script>";				

				}else{

				echo'

					<table class="table">
					<tr>
						<th width="5%"> S/N  </th>
						<th width="15%">Name  </th>
						<th width="5%">Class  </th>
						<th width="5%"> Term </th>
						<th width="10%"> Session </th>
						<th width="15%">Subject  </th>
						<th width="15%">Test Score </th>
						<th width="15%">Exam Score  </th>
						<th width="15%">Total  </th>
						<th width="15%">Action  </th>
					</tr>


				';

			while($row = mysqli_fetch_array($result)){

					$no++;
					$test = $row["test_score"];
					$exam = $row["exam_score"];
					$id = $row["id"];
					$total = $test + $exam;
					echo'

						<tr>
							<td> '.$no.'</td>
							<td> '.$row["student_name"].'</td>
							<td> '.$row["class"].'</td>
							<td> '.$row["term"].'</td>
							<td> '.$row["session"].'</td>
							<td> '.$row["subject"].' </td>
							<td><input type="text" name="test" class="form-control test" pid="'.$id.'" id="test-'.$id.'" value="'.$row["test_score"].'" /></td>
							<td><input type="text" name="exam" class="form-control exam" pid="'.$id.'" id="exam-'.$id.'" value="'.$row["exam_score"].'" /></td>
							<td> '.$total.'</td>
							<td><a href="#" result_id="'.$id.'" class="btn btn-success result">Update</a> </td>
							
							


					';
					

				}

			}
				
				echo "</table>";
			}


?>