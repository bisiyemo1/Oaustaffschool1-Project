<?php

include "connection.php";
$msg = "";
if(isset($_POST['edit_teacher'])){

$name = $_POST['t_name'];
$id = $_POST['id'];
$username = $_POST['username'];
$class = $_POST['class'];
$phone = $_POST['phone'];
$user_role = "Teacher";
$password = $_POST['password'];
$password2 = $_POST['password'];
$status = $_POST['status'];


if((!$name)  || (!$username) || (!$class) || (!$password)  || (!$phone)){


	echo  "<script type=\"text/javascript\">alert('Please fill all the field');
						window.location='edit-teacher.php?details=$id'</script>";

			}
						
	
	else{

				$password = md5($password);

				$sql = "UPDATE user set username='$username',status='$status',name='$name',
				phone='$phone',class='$class',password='$password',password2='$password2' where username='$username' ";
				if(mysqli_query($con, $sql)){


					echo  "<script type=\"text/javascript\">alert('$name Details Edited Successfully');
						window.location='edit-teacher.php?details=$id'</script>";


				}

				

			else{


				echo  "<script type=\"text/javascript\">alert('$parent_name Details NOT Successfully Edited');
						</script>";

			}



	}

}

?>