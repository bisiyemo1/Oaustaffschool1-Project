<?php
require_once("connection.php");
if($_SESSION['user_role'] != "Parent"){

header("location: logout.php");
}



?>
<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
    <title>OAU STAFF SCHOOL - ADMINISTRATIVE PANEL</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
	    
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
	
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
	    
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	
	<link href="home/css/bootstrap.min.css" rel="stylesheet" />
	<link href="CustomStyleHome.css" rel="stylesheet" />

</head>

<body>
	
					<!--Code for navigation bar and Header-->
					
					<nav id="mainNavbar" >  

					<!--Code for header only-->
							
						
							<div class="row">
								<div class="col-xs-12">

									<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
										<div class="panel-heading">
										
											<div id="customDiv2">
												<img class="img-responsive" src="images/schoollogo.jpg">
											</div>
										
										
											<h3 class="panel-title">OBAFEMI AWOLOWO UNIVERSITY STAFF SCHOOL<h3>
											
										</div>
							
									</div>
								</div>
							</div>
				
									
					<!--Code for Navigation bar using breadcrumb-->
														
									<div class="row">
										<div class="col-xs-12">
													<!--NOTE: The forward slash "/" of the breadcrumb is changed to vertical slash"|". The background color or other things, can also be changed to your desire color(yellow)-->
							
												<ol class="breadcrumb">
														<li class="active"><a href="index.php">Home</a></li>
														<li class="active"><a href="about.php">About</a></li>
														<li class="active"><a href="login.php">Portal</a></li>
														 <ul class="nav pull-right active">	
														     <li class="">						
															     <a href="logout.php" class="">
																     Logout
													       		</a>
														     </li>
													    </ul>
												</ol>

										</div>
									</div>
															
					</nav> 



<div class="container">
	
	<div class="row">
		
		<div class="span12">
			
			<div class="error-container">
				<h4>Welcome</h4>
				<h3 style="color:green;"><?php echo $_SESSION["name"];  ?></h3>
				<h2>You have successfully logged in to Parent's Portal</h2>
				
				<div class="error-details">
					  <a href="#"></a> 
					
				</div> <!-- /error-details -->
				
				
					
					
				</div> <!-- /error-actions -->
				<center>
				<div class="form-actions">
												<a href="check-result.php"><button type="submit" class="btn btn-primary">Check Result</button></a>
												<a href="messages.php"><button type="submit" class="btn btn-primary">Message</button></a>
												
												
												

                                                
											</div>		</center>	
			</div> <!-- /error-container -->			
			
		</div> <!-- /span12 -->
		
	</div> <!-- /row -->
	
</div> <!-- /container -->


<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

</body>

</html>
