<?php
ini_set('display_errors', '1');
session_start();
$con = mysqli_connect("localhost","root","","oaustaff");

if (mysqli_connect_errno())
  {
  echo "The Connection was not established: " . mysqli_connect_error();
  }


 						if(isset($_POST['viewStudent'])){

 							echo "<table border='1' style='width:100%; color:green; text-align:center;'>
						<thead style='background-color:green; color:white'>

							<th>S/No</th>
							<th>Name</th>
							<th>Sex</th>
							<th>Class</th>
							<th>Date Added</th>
							<th>Status</th>
							<th>Update</th>
							<th>Delete</th>
							<th>Edit</th>

							
							</thead>";

							$num_result = mysqli_query($con, "SELECT count(*) as total_count from student_record where class = '$_SESSION[class]' 
								and sex = 'M' and status = 'ACTIVE'");
				            $row = mysqli_fetch_object($num_result);

				            $num_result1 = mysqli_query($con, "SELECT count(*) as total_count from student_record where class = '$_SESSION[class]' 
				             and sex = 'F' and status = 'ACTIVE'");
				            $row1 = mysqli_fetch_object($num_result1);

				            echo "<div class='control-group'>
							<label class='control-label'><h2>NUMBER OF MALE STUDENTS  $row->total_count</h2></label>
							<div class='controls'>
							<div class='progress'>
				             <div class='bar' style='width: $row->total_count%;'></div>
				              </div></div>
				         </div>
				         <div class='control-group'>
							<label class='control-label'><h2>NUMBER OF FEMALE STUDENTS  $row1->total_count</h2></label>
							<div class='controls'>
							<div class='progress'>
				             <div class='bar' style='width:$row1->total_count%;'></div>
				              </div></div>
				         </div>";


 							 $no = 0;
							$sql = "SELECT * FROM student_record where class = '$_SESSION[class]' order by student_name";
							$run_sql = mysqli_query($con,$sql);

							while($row=mysqli_fetch_array($run_sql)){
	
							$name = $row['student_name'];
							$id = $row['id'];
							$sex = $row['sex'];
							$class = $row['class'];
							$status= $row['status'];
							$date_added = $row['date_added'];
							

							$no++;
							
							
							echo "<tr>
							<td> $no</td>
							<td  style='text-align:justify;'>$name</td>
							<td> $sex  </td>
							<td> $class </td>
							
							<td> $date_added  </td>
							<td>

								<select class='form-control status' pid='$id' id='status-$id' value='$status'>
									<option> $status </option>
									<option value='ACTIVE'>ACTIVE</option>
									<option value='INACTIVE'>INACTIVE</option>
								</select>

							<input type='hidden' name='id' class='form-control id' pid='$id' id='id-$id' value='$id'; '>
							</td>
							<td><button update_id='$id' class='btn btn-success update'>Update</button></td></td>
							<td><button remove_id='$id' class='btn btn-success remove'>Delete</button></td></td>
							<td><a href='edit-student.php?request=$id' class='btn btn-success' >Edit</a> </td></td>
							
							
						</tr>";
							}


						}


			if(isset($_POST["updateStudentStatus"])){

				$pid = $_POST["updateId"];

				$status = $_POST["status"];
				


				$sql2 = "UPDATE student_record set status = '$status' where id='$pid' ";
				if(mysqli_query($con,$sql2)){


					echo " <script type=\"text/javascript\">alert('Student's Status Updated Successfully');
						</script>";


		
		}else{

			echo " <script type=\"text/javascript\">alert('Operation not successful');
						</script>";
		}

	}

	if(isset($_POST["updateArrivalPayment"])){

				$pid = $_POST["updateId"];

				$status = $_POST["status"];
				


				$sql2 = "UPDATE booking set payment_status = '$status' where id='$pid' ";
				if(mysqli_query($con,$sql2)){


					echo " <script type=\"text/javascript\">alert('Payment On Arrival has been set to $status');
						window.location='pay-on-arrival.php'</script>";


		
		}

	}

		if(isset($_POST["updatebankPayment"])){

				$pid = $_POST["updateId"];

				$status = $_POST["status"];
				


				$sql2 = "UPDATE booking set payment_status = '$status' where id='$pid' ";
				if(mysqli_query($con,$sql2)){


					echo " <script type=\"text/javascript\">alert('Bank Payment has been set to $status');
						window.location='bank-deposit.php'</script>";


		
		}

	}

			if(isset($_POST["removeStudent"])){

			$pid = $_POST["removeId"];
			$sql = "DELETE FROM student_record WHERE id = '$pid'";
			$run_query = mysqli_query($con,$sql);
			if($run_query){

				echo "

					 <script type=\"text/javascript\">alert('Students Record Deleted Successfully');
						</script>";

				

			}

		}


						if(isset($_POST['viewStudentDetail'])){

							
 							
							$sql = "SELECT * FROM student_record where student_name = '$_SESSION[student_name]'";
							$run_sql = mysqli_query($con,$sql);
							while($row=mysqli_fetch_array($run_sql)){
	
									$name = $row['student_name'];
									$sex = $row['sex'];
									$status = $row['status'];


								echo "
									<div style='color:green;'>
									<div>Name: <span>$name</span></div>
									
									<div>Status: <span>$status</span></div>
									<div>Term: <span>$_SESSION[term]</span></div>
									<div>Session: <span>$_SESSION[session]</span></div>
									<div>Class: <span>$_SESSION[class]</span></div>
									</div>

								";
									

							
							}


						}


					if(isset($_POST['viewTeacherDetail'])){

							
 						

								echo "
									<div style='color:green;'>
									<div>Generated By: <span>$_SESSION[name]</span></div>	
									<div>Student Name: <span>$_SESSION[student_name]</span></div>	
									<div>Term: <span>$_SESSION[term]</span></div>
									<div>Session: <span>$_SESSION[session]</span></div>
									<div>Class: <span>$_SESSION[class]</span></div>
									</div>

								";
									

							
							}


						

	
							

					if(isset($_POST['Compose'])){

						$pro_id = 2;
						echo "

							<ul>
								<li>
								
								<button compose_id='1' class='btn btn-warning compose'>Compose</button>
								</li>
								
								<br>
								<li>
								<a href='#' inbox_id='2' class='btn inbox' style='background-color:green; color:white;'>Inbox</a>
								</li>
								<br>
								<li>
								<a href='#' sent_id='3' class='btn btn-failure sent'>Sent</a>
								</li>

							</ul>


						";
					}


					if(isset($_POST['ComposeMessage'])){

						if($_SESSION['user_role'] == 'Parent'){
						echo "

						<form action='composemsg.php' method='post'>
		
							<h1>Compose Message</h1>			
							
							<div class='login-fields'>
								<div class='field'>";

							
							echo "
								<input type='hidden' name='name' value='$_SESSION[name]'  />
								</div> <!-- /field -->
								<div class='field'></div>
								<select name='name' style='width:100%;'><option value=''>Select Student Name</option>";
								$sql = "SELECT * from student_record where parent_name='$_SESSION[name]' ";
								$run_sql = mysqli_query($con,$sql);
								while($row=mysqli_fetch_array($run_sql)){
	
									$name = $row['student_name'];
									$parent_name= $row['parent_name'];
									
									

								

								echo "
								
								<option value='$parent_name'>$name</option>";
								}
								
								echo "</select>
								<div>
									<select name='message' style='width:100%;'>
								<option value=''>Select Message</option>
								<option value='is sleeping in Class through-out today'>is sleeping in Class through-out today</option>
								<option value='assignment was not done yesterday'>assignment was not done yesterday </option>
								<option value='is sick today '>is sick today </option>
								<option value='will be travelling tomorrow '>travelling tomorrow </option>
								<option value='should be taken care of for adequate well being'>should be taken care of for adequate well being</option>
								
								</select>";

								echo "</select>
									</div>";

								echo "<div>
									<label>Select Student Subject</label>
									<select name='class' style='width:100%;'>
										<option value=''>Select Class</option>";

									$sql = "SELECT * FROM class ";
								$run_sql = mysqli_query($con,$sql);

								while($row=mysqli_fetch_array($run_sql)){
						
								$name = $row["name"];
								

								

								echo "<option value='$name'>$name</option>";
								}
								echo "</select>
									</div>";
									
								echo "



								
								<div>

								<input type='submit' class='btn btn-success' name='composemsg' id='composemsg' value='Send' />
								</div>
								</form>

								";

					}

					if($_SESSION['user_role'] == 'Teacher'){
						echo "

						<form action='composemsg.php' method='post'>
		
							<h1>Compose Message</h1>			
							
							<div class='login-fields'>
								<div class='field'>";

								echo "<select name='name' style='width:100%;'><option value=''>Select Student Name</option>";
								$sql = "SELECT * from student_record order by student_name";
								$run_sql = mysqli_query($con,$sql);
								while($row=mysqli_fetch_array($run_sql)){
	
									$name = $row['student_name'];
									$class = $row['class'];
									$parent_name= $row['parent_name'];

								

								echo "
								
								<option value='$parent_name'>$name</option>";
								}
								
								echo "</select>";
								

							
								
								echo "

								<select name='message' style='width:100%;'>
								<option value=''>Select Message</option>
								<option value='is sleeping in Class through-out today'>is sleeping in Class through-out today</option>
								<option value='assignment was not done yesterday'>assignment was not done yesterday </option>
								<option value='is sick today in school'>is sick today in school</option>
								<option value='should be taken care of for adequate well being'>should be taken care of for adequate well being</option>
								
								</select>";

								echo "
								<div>
									<label>Class</label>
									<input type='text' id='class' name='class' value='$_SESSION[class]' class='username' style='width:100%;' disabled/>
								
									</div>

								
								
								<input type='hidden' name='class' value='$_SESSION[class]' />		
								<div class='field'>
									
									
									
								</div> <!-- /field -->
								<div>
								<input type='hidden' name='user_role' value='$_SESSION[user_role]' />
								<input type='submit' class='btn btn-success' name='composemsg' id='composemsg' value='Send' />
								</div>
								</form>

								";

					}


				}

			



					if(isset($_POST['InboxMessage'])){

						$user_role = '';

						echo "<table border='1' style='width:100%; color:green; text-align:center;'>
						<thead style='background-color:green; color:white'>

							
							<th>Title</th>
							<th>Message</th>
							<th>Sent By</th>
							<th>Subject</th>
							<th>Student Name</th>
							<th>Class </th>
							<th>Date Received</th>
							<th>Action </th>
							

							
							</thead>";

							if($_SESSION['user_role'] == 'Teacher'){

								$user_role = 'Parent';

							}elseif ($_SESSION['user_role'] == 'Parent') {
								$user_role = 'Teacher';
							}
							$sql = "SELECT * FROM inbox where receiver = '$_SESSION[name]' and user_role='$user_role' and action1=0 order by msg_date DESC" ;
							$run_sql = mysqli_query($con,$sql);
							while($row=mysqli_fetch_array($run_sql)){
	
									$id = $row['id'];
									$title = $row['title'];
									$message = $row['message'];
									$sender = $row['sender'];
									$receiver= $row['receiver'];
									$class = $row['class'];
									$subject = $row['subject'];
									$date = $row['msg_date'];
									$student_name = $row['student_name'];
									$class = $row['class'];


								echo "
								<tbody>
									<tr>
										<td>$title</td>
										<td>$message</td>
										<td>$sender</td>
										<td>$subject </td>
										<td>$student_name</td>
										<td>$class</td>
										<td>$date</td>
										<td><button delete_id='$id' class='btn btn-success deleteInbox'>Delete</button></td></td>
									</tr>

									</tbody>

									

								";
								
								}

								echo "</table>";

					}

					if(isset($_POST['SentMessage'])){

						echo "<table border='1' style='width:100%; color:orange; text-align:center;'>
						<thead style='background-color:orange; color:white'>

							
							<th>Title</th>
							<th>Message</th>
							<th>Class</th>
							<th>Date Sent</th>
							<th>Action </th>
							

							
							</thead>";


							$sql = "SELECT * FROM inbox where sender = '$_SESSION[name]' and user_role='$_SESSION[user_role]' and action2=0 order by msg_date DESC" ;
							$run_sql = mysqli_query($con,$sql);
							while($row=mysqli_fetch_array($run_sql)){
	
									$id = $row['id'];
									$title = $row['title'];
									$message = $row['message'];
									$sender = $row['sender'];
									$parent_name = $row['student_name'];
									$class = $row['class'];
									$subject = $row['subject'];
									$date = $row['msg_date'];


								echo "
								<tbody>
									<tr>
										<td>$title</td>
										<td>$message</td>
										<td>$class</td>
										<td>$date</td>
										<td><button delete_id='$id' class='btn btn-warning DeleteSent'>Delete</button></td></td>
									</tr>

									</tbody>

									

								";

								}

								
								echo "</table>";
					}


					if(isset($_POST['removeInboxMsg'])){

						$pid = $_POST["removeId"];
			
				$sql2 = "UPDATE inbox set action1=1 where id='$pid' ";
						
						$run_query = mysqli_query($con,$sql2);
						if($run_query){
					echo " <script type=\"text/javascript\">alert('Message Deleted Successfully');
						</script>";


				}


			}

			if(isset($_POST['removeSentMsg'])){

						$pid = $_POST["removeId"];
			
				$sql2 = "UPDATE inbox set action2=1 where id='$pid' ";
						
						$run_query = mysqli_query($con,$sql2);
						if($run_query){
					echo " <script type=\"text/javascript\">alert('Message Deleted Successfully');
						</script>";


				}


			}


			if(isset($_POST['AllDetails'])){

							$class = $_POST['Class'];

 							echo "<table border='0' style='width:100%; color:blue; text-align:left; right:10px;'>
						<thead style='background-color:violent; border-color:red;'>

							<th>S/No</th>
							<th>Name</th>
							<th>Parent</th>
							<th>Email</th>
							<th>Phone</th>
							<th>Class</th>
							<th>Status</th>
							<th>Action</th>
							
							
							</thead>";

							

							$no = 0;
							$sql = "SELECT * FROM student_record where class = '$class' order by student_name";
							$run_sql = mysqli_query($con,$sql);

							while($row=mysqli_fetch_array($run_sql)){
	
							$name = $row['student_name'];
							$id = $row['id'];
							$parent = $row['parent_name'];
							$sex = $row['sex'];
							$class = $row['class'];
							$status= $row['status'];
							$email= $row['email'];
							$phone= $row['phone'];
							$date_added = $row['date_added'];

							$no++;

							if(empty($email)){

								$email= "No email";

							}else{

								 $email;
							}

							echo "
								<tr>

								<td>$no</td>
								<td>$name</td>
								<td>$parent</td>
								<td>$email</td>
								<td>$phone</td>
								<td>$class</td>
								<td>$status</td>
								<td><a href='edit-record.php?details=$id' class='btn btn-success'>Edit</a></button></td>
								
								
							
								
								</tr>

							";


				}

			}



			if(isset($_POST['editRecord'])){

							$pid = $_POST['editId'];



							$sql = "SELECT * FROM student_record where id= '$pid'";
							$run_sql = mysqli_query($con,$sql);

							while($row=mysqli_fetch_array($run_sql)){
	
							$name = $row['student_name'];
							$id = $row['id'];
							$parent = $row['parent_name'];
							$sex = $row['sex'];
							$class = $row['class'];
							$status= $row['status'];
							$email= $row['email'];
							$phone= $row['phone'];
							$date_added = $row['date_added'];


					echo '		<center>
							<br>
							<br>
			<form action="edit_record.php" method="post" id="myform" enctype="multipart/form-data">
		
			<h3 style="color:red;">You are Editing '.$parent.' Details</h3>			
			
			<div class="login-fields">
				<div class="field">
					<label for="firstname">Parent Name</label>
					<input type="text" id="p_name" name="p_name" placeholder="Parent Name" value="'.$parent.'" class="username" />
				</div> 
			<div class="field">
					<label for="firstname">Student Name</label>
					<input type="text" id="username" name="stu_name" placeholder="Student Name" value="'.$name.'" class="username" />
				</div> 	
				<div class="field">
					<label for="firstname">Class</label>
					<input type="text" id="username" name="class" placeholder="Class" value="'.$class.'" class="username" />
				</div>
			<div class="field">
					<label for="firstname">Email</label>
					<input type="text" id="username" name="email" placeholder="Email" value="'.$email.'" class="username" />
				</div> 
				
				
				<div class="field">
					<select class="username" name="status" style="width:28%;">
						<option value="'.$status.'">'.$status.'</option>
					<option value="ACTIVE">ACTIVE</option>	
					<option value="INACTIVE">INACTIVE</option>
					</select>
				</div>
								
				
				<div class="field">
					<label for="phone">Phone Number</label>	
					<input type="text" id="phone" name="phone" placeholder="Phone Number" value="'.$phone.'" class="login" />
				</div> 
				<div class="field">
					<select class="username" name="sex" style="width:28%;">
						<option value="'.$sex.'">'.$sex.'</option>
					<option value="male">Male</option>	
					<option value="female">Female</option>
					</select>
				</div>';


				$sql = "SELECT * FROM user where username='$email'";
							$run_sql1 = mysqli_query($con,$sql);

							while($row=mysqli_fetch_array($run_sql1)){
	
							$password = $row['password2'];
						
						}
						echo'
							<div class="field">
					<label> Password</label>	
					<input type="text" id="phone" name="password" placeholder="Password" value="'.$password.'" class="login" />
				</div> 

						

						
				
			<input type="submit" style="width:30%; margin-right:420px;" class="button btn btn-success btn-large" name="edit_record" id="edit_record" value="Edit">
			
			</div> 

					</div>
				
			</div>';
			
			
			
		echo '</form>
		</center>
							';

							
						}

					}


					if(isset($_POST['viewTeacher'])){

							

 							echo "<table border='0' style='width:100%; color:blue; text-align:left; right:10px;'>
						<thead style='background-color:violent; border-color:red;'>

							<th>S/No</th>
							<th>Name</th>
							<th>Email</th>
							<th>Class</th>
							<th>Phone</th>
							<th>Status</th>
							<th>Action</th>
							
							
							</thead>";

							

							$no = 0;
							$sql = "SELECT * FROM user where user_role='Teacher' ";
							$run_sql = mysqli_query($con,$sql);

							while($row=mysqli_fetch_array($run_sql)){
	
						
							$id = $row['id'];
							$name = $row['name'];
							
							$class = $row['class'];
							$status= $row['status'];
							$username= $row['username'];
							$phone= $row['phone'];
							

							$no++;

							if(empty($email)){

								$email= "No email";

							}else{

								 $email;
							}

							echo "
								<tr>

								<td>$no</td>
								<td>$name</td>
								<td>$username</td>
								<td>$class</td>
								<td>$phone</td>
								<td>$status</td>
								<td><a href='edit-teacher.php?details=$id' class='btn btn-success'>Edit</a></button></td>
								
								
							
								
								</tr>

							";


				}

			}


					if(isset($_POST['ResultMessage'])){


						$test = $_POST["test"];
						$exam = $_POST["exam"];

						$pid = $_POST["resultId"];
			
				$sql2 = "UPDATE student_result set test_score='$test',exam_score='$exam' where id='$pid' ";
						
						$run_query = mysqli_query($con,$sql2);
						if($run_query){
					echo " <script type=\"text/javascript\">alert('Result Updated Successfully');
						</script>";


				}else{

					echo " <script type=\"text/javascript\">alert('$pid');
						</script>";

				}


			}


?>