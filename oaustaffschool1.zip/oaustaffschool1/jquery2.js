$(document) .ready(function(){

$("#composemsg").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "composemsg.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#composeMsg") .html(data);
			

		}

})


})

})