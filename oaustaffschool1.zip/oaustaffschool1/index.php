 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OAU STAFF SCHOOL</title>
    <link href="home/css/bootstrap.min.css" rel="stylesheet">
	<link href="CustomStyleHome.css" rel="stylesheet" />
	
	<link href="CustomStyleHome1.css" rel="stylesheet" />

	<style type="text/css">
		
		body{ position: relative; }

	</style>

  </head>

  <body data-spy="scroll" data-target="#mainNavbar" data-offset="10" onload="slideA()">

					<!--Code for navigation bar and Header-->
					
					<nav id="mainNavbar" >  

					<!--Code for header only-->
							
						
							<div class="row">
								<div class="col-xs-12">

									<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
										<div class="panel-heading">
										
											<div id="customDiv2">
												<img class="img-responsive" src="images/schoollogo.jpg">
											</div>
										
										
											<h3 class="panel-title">OBAFEMI AWOLOWO UNIVERSITY STAFF SCHOOL<h3>
											
										</div>
							
									</div>
								</div>
							</div>
				
									
					<!--Code for Navigation bar using breadcrumb-->
														
									<div class="row">
										<div class="col-xs-12">
													<!--NOTE: The forward slash "/" of the breadcrumb is changed to vertical slash"|". The background color or other things, can also be changed to your desire color(yellow)-->
							
												<ol class="breadcrumb">
														<li class="active"><a href="index.php">Home</a></li>
														<li><a href="about.php">About</a></li>
														<li><a href="login.php">Portal</a></li>
												</ol>

										</div>
									</div>
															
					</nav>    


<!--<div class="wrapper"> -->

		<!--Code for Column Picture slide show-->			
<div class="container">
	<div class="row">
			
			<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
				<div class="panel-body">

					<div class="col-sm-4 col-md-4">
						<div class="customDiv">
							SCHOOL FIELD
							<div class="schfield">
							<img src="images/schGround.jpg" />
							</div>
						</div>
					</div>

					<div class="col-sm-4 col-md-4">
						<div class="customDiv">

							<img src="images/field1.jpg" id="field" />
							<div id="left_holder"> <img onClick="slide(-1)" class="left" src="images/a10.png"/> </div>
							<div id="right_holder"> <img onClick="slide(1)" class="right" src="images/a11.png"/> </div>	
												
						</div>
					</div>

					<div class="col-sm-4 col-md-4">
						<div class="customDiv">
							FINE ART LAB
							<div class="schfield">
							<img src="images/fineArt.jpg" />
							</div>
						</div>
					</div>

				</div>				
			</div>

		
			<div class="container">
				<br /><br />
				<div class="row">
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3>Home</h3> "About page is specially design to welcome you specially and to give you unique view of our school and..."<a href="index.php">more</a>"
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3>About</h3>About page is specially design to know us better, what we stand for, our impact globally and..."<a href="about.php">more</a>"
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<h3>Portal</h3> "Portal page is specially design to give you easy access to check your children's results online and..."<a href="portal.php">more</a>"
						</div>
					</div>
				</div>
			</div>			
	</div>				
</div>
				
<!--</div>-->

	<!-- For footer -->

		<div id="footer"> 

			<div id="copyright">
				&copy; Copyright 2018 by OAU STAFF SCHOOL. All right reserved.
			</div>
	
			<div id="sociallink">
		
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" /></a>
				<a href="http://www.yahoomail.com"><img src="images/email.jpg" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" /></a>
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" /></a>
			</div>
	
		</div>






















			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>

			<script type="text/javascript">
				var imagecount = 1;
				var total = 6;

				function slide(x) {
				var Image = document.getElementById('field');
				imagecount = imagecount + x;
				if(imagecount > total){ imagecount = 1;}
				if(imagecount < 1){ imagecount = total;}
				Image.src = "images/field"+ imagecount +".jpg"; 
				}
		
				window.setInterval(function slideA(x) {
				var Image = document.getElementById('field');
				imagecount = imagecount + 1;
				if(imagecount > total){ imagecount = 1;}
				if(imagecount < 1){ imagecount = total;}
				Image.src = "images/field"+ imagecount +".jpg"; 
				},3000);
  			</script>


    </body>
</html>