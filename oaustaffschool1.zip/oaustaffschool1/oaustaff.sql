-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2018 at 08:34 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oaustaff`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `name`) VALUES
(1, '4K'),
(3, '4L'),
(6, '4J'),
(7, '4M'),
(8, '4N'),
(9, '4O'),
(10, '5J'),
(11, '5K'),
(12, '5L'),
(13, '6J');

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE `inbox` (
  `id` int(11) NOT NULL,
  `title` varchar(225) NOT NULL,
  `message` text NOT NULL,
  `user_id` int(50) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `user_role` varchar(20) NOT NULL,
  `class` varchar(20) NOT NULL,
  `msg_date` datetime NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `status` text NOT NULL,
  `action1` int(11) NOT NULL,
  `action2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inbox`
--

INSERT INTO `inbox` (`id`, `title`, `message`, `user_id`, `sender`, `student_name`, `user_role`, `class`, `msg_date`, `receiver`, `subject`, `status`, `action1`, `action2`) VALUES
(15, 'Thanks', 'Thank you sir for great job done. More grace.', 0, 'Mr. & Mrs. Falana', 'Falana Olufolabi', 'Parent', '4K', '2017-12-17 05:56:59', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 1),
(16, 'Thanks', 'Good job sir. More grace to your palm', 0, 'Mr. & Mrs. Falana', 'Falana Olufolabi', 'Parent', '4K', '2017-12-17 06:00:37', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(17, 'thnaks sir', 'i will see to the method ', 0, 'Mr. Femi Caleb', 'Falana Olufolabi', 'Teacher', '4K', '2017-12-17 06:08:43', 'Mr. & Mrs. Falana', 'Social Studies', 'inbox', 0, 1),
(18, 'This is my story', 'Whatever you send out will be in your sent item', 0, 'Mr. Femi Caleb', 'Falana Olufolabi', 'Teacher', '4K', '2017-12-17 06:24:35', 'Mr. & Mrs. Falana', 'Social Studies', 'inbox', 1, 1),
(19, 'WELCOME TO A NEW MONTH', 'THNAKS', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4J', '2017-12-30 09:58:23', 'Mr. Wolekemi Dada', 'Social Studies', 'inbox', 0, 1),
(20, 'WELCOME TO A NEW MONTH NOTHER', 'YES', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4J', '2017-12-30 10:13:18', 'Mr. Wolekemi Dada', 'Mathematics', 'inbox', 0, 0),
(21, 'FROM SUNDAY', 'PLEASE HELP TO REVIEW THE MESSAGE', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4J', '2017-12-30 11:05:30', 'Mr. Wolekemi Dada', 'Social Studies', 'inbox', 0, 0),
(22, 'WELCOME TO A NEW MONTH', 'thanks', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4J', '2017-12-30 11:11:03', 'Mr. Wolekemi Dada', 'Social Studies', 'inbox', 0, 0),
(23, 'WELCOME TO A NEW MONTH', 'thanks', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4J', '2017-12-30 11:12:26', 'Mr. Wolekemi Dada', 'Social Studies', 'inbox', 0, 0),
(24, 'WELCOME TO A NEW MONTH', 'thnaks', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4J', '2017-12-30 11:15:33', 'Mr. Wolekemi Dada', 'Social Studies', 'inbox', 0, 0),
(25, 'WELCOME TO A NEW MONTH', 'thnkas', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4J', '2017-12-30 11:17:18', 'Mr. Wolekemi Dada', 'Social Studies', 'inbox', 0, 0),
(26, 'FROM SUNDAY', 'this is a sms message', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4J', '2017-12-30 11:23:10', 'Mr. Wolekemi Dada', 'Social Studies', 'inbox', 0, 1),
(27, 'WELCOME TO A NEW MONTH', 'this', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4J', '2017-12-30 11:26:49', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(28, 'FROM SUNDAY', 'tsdfsfsd', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4J', '2017-12-30 11:29:04', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(29, 'FROM SUNDAY', 'zddsa', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4J', '2017-12-30 11:29:53', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(30, 'FROM SUNDAY', 'ths', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4J', '2017-12-30 11:34:35', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(31, 'FROM SUNDAY', 'thssjsjs', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4J', '2017-12-30 11:34:56', 'Mr. Wolekemi Dada', 'Mathematics', 'inbox', 0, 0),
(32, 'WELCOME TO A NEW MONTH', 'dsffds', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4J', '2017-12-30 11:36:19', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(33, 'FROM SUNDAY', 'gfdsfdsfd', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 11:57:20', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(34, 'WELCOME TO A NEW MONTH', 'this is me', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 11:59:53', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(35, 'WELCOME TO A NEW MONTH', 'fdsfsdf', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:02:41', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(36, 'WELCOME TO A NEW MONTH', 'cxzcxzc', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:06:02', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(37, 'WELCOME TO A NEW MONTH', 'xsx', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:06:52', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 0, 0),
(38, 'WELCOME TO A NEW MONTH', 'ddd', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:07:36', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(39, 'WELCOME TO A NEW MONTH', 'ssd', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:08:05', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(40, 'WELCOME TO A NEW MONTH', 'tdsdfdsddf', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:11:40', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(41, 'WELCOME TO A NEW MONTH', 'hhhh', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:12:11', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(42, 'WELCOME TO A NEW MONTH', 'dczxc', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:12:55', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(43, 'WELCOME TO A NEW MONTH', 'dczxc', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:13:22', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(44, 'WELCOME TO A NEW MONTH', 'sdsadsad', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4L', '2017-12-30 12:13:52', 'Mr. Femi Caleb', 'Social Studies', 'inbox', 1, 0),
(45, 'This is the', 'ddd', 0, 'Mr. Femi Caleb', 'Adegbaju Adedolapo', 'Teacher', '4L', '2018-01-12 06:30:52', 'Mr and Mrs Adegbaju', '', 'inbox', 0, 0),
(46, '', 'is sleeping in Class through-out today', 0, 'Mr. Femi Caleb', 'Adebowale Ayisat', 'Teacher', '4L', '2018-01-12 07:34:04', 'Mr. & Mrs. Adebowale', '', 'inbox', 0, 0),
(47, 'Alert', 'assignment was not done yesterday', 0, 'Mr. Femi Caleb', 'Adejumo Anthony', 'Teacher', '4L', '2018-01-12 07:35:11', 'Mr. & Mrs. Adejumo', '', 'inbox', 0, 0),
(48, 'Alert', 'is sleeping in Class through-out today', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-12 07:44:13', '', '', 'inbox', 0, 0),
(49, 'Alert', 'is sleeping in Class through-out today', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-12 07:44:56', '', '', 'inbox', 0, 0),
(50, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-12 08:16:43', 'sunday', '', 'inbox', 0, 0),
(51, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-13 08:35:50', 'sunday', '', 'inbox', 0, 0),
(52, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-13 08:47:41', 'sunday', '', 'inbox', 0, 0),
(53, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-13 08:49:33', 'sunday', '', 'inbox', 0, 0),
(54, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-13 08:51:04', 'sunday', '', 'inbox', 0, 0),
(55, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-13 08:53:00', 'sunday', '', 'inbox', 0, 0),
(56, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '4K', '2018-01-13 08:54:22', 'sunday', '', 'inbox', 0, 0),
(57, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4K', '2018-01-13 08:55:49', 'sunday', '', 'inbox', 0, 0),
(58, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4K', '2018-01-13 08:56:19', 'sunday', '', 'inbox', 0, 0),
(59, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4K', '2018-01-13 09:02:51', 'sunday', '', 'inbox', 0, 0),
(60, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4K', '2018-01-13 09:03:09', 'sunday', '', 'inbox', 1, 0),
(61, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Femi Caleb', 'Dada Oluwafeyikemi', 'Teacher', '4K', '2018-01-13 09:05:21', 'Mr. Wolekemi Dada', '', 'inbox', 1, 0),
(62, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'Parent', '4K', '2018-01-13 04:46:54', 'sunday', '', 'inbox', 0, 0),
(63, 'Alert', 'is sick today in school', 0, 'sunday', '', 'Teacher', '4K', '2018-01-15 01:39:24', '', '', 'inbox', 0, 0),
(64, 'Alert', 'should be taken care of for adequate well being', 0, 'sunday', '', 'Teacher', '4K', '2018-01-15 01:40:34', '', '', 'inbox', 0, 0),
(65, 'Alert', 'is sleeping in Class through-out today', 0, 'sunday', '', 'Teacher', '4K', '2018-01-15 01:49:07', '', '', 'inbox', 0, 0),
(66, 'Alert', 'should be taken care of for adequate well being', 0, 'sunday', '', 'Teacher', '4K', '2018-01-15 01:49:37', '', '', 'inbox', 0, 0),
(67, 'Alert', 'is sleeping in Class through-out today', 0, 'sunday', 'Dada Oluwafeyikemi', 'Teacher', '4K', '2018-01-15 01:51:32', 'Mr. Wolekemi Dada', '', 'inbox', 0, 0),
(68, 'Alert', 'is sick today in school', 0, 'sunday', '', 'Teacher', '4K', '2018-01-15 01:51:45', '', '', 'inbox', 0, 0),
(69, 'Alert', 'is sick today in school', 0, 'sunday', 'Adebowale Ayisat', 'Teacher', '4K', '2018-01-15 01:52:29', 'Mr. & Mrs. Adebowale', '', 'inbox', 0, 0),
(70, 'Alert', 'is sleeping in Class through-out today', 0, 'sunday', '', 'Teacher', '4K', '2018-01-15 01:52:59', '', '', 'inbox', 0, 0),
(71, 'Alert', 'assignment was not done yesterday', 0, 'Alabi Pau', '', 'Teacher', '4J', '2018-01-15 08:59:53', '', '', 'inbox', 0, 0),
(72, 'Alert', 'is sick today ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-01-26 06:06:51', 'Alabi Paul', '', 'inbox', 1, 0),
(73, 'Alert', 'is sick today ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-01-28 03:19:43', 'Alabi Paul', '', 'inbox', 1, 0),
(74, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-02-15 08:55:23', 'Alabi Paul', '', 'inbox', 1, 0),
(75, 'Alert', 'is sick today ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-02-15 09:15:07', 'Alabi Paul', '', 'inbox', 1, 0),
(76, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-02-16 12:24:22', 'Alabi Paul', '', 'inbox', 1, 0),
(77, 'Alert', 'is sick today in school', 0, 'Alabi Paul', 'Adebowale Ayisat', 'Teacher', '4J', '2018-02-16 10:10:36', 'Mr. & Mrs. Adebowale', '', 'inbox', 0, 0),
(78, 'Alert', 'will be travelling tomorrow ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-02-23 10:15:01', 'Alabi Paul', '', 'inbox', 1, 0),
(79, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-03-08 02:32:55', 'Alabi Paul', '', 'inbox', 1, 0),
(80, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-03-09 11:36:33', 'Alabi Paul', '', 'inbox', 1, 0),
(81, 'Alert', 'is sleeping in Class through-out today', 0, 'Alabi Paul', '', 'Teacher', '4J', '2018-03-11 03:07:20', 'Mr. & Mrs. Olatayo', '', 'inbox', 1, 0),
(82, 'Alert', 'assignment was not done yesterday', 0, 'Alabi Paul', '', 'Teacher', '4J', '2018-03-11 03:17:56', 'Mr. & Mrs. Olatayo', '', 'inbox', 0, 0),
(83, 'Alert', 'assignment was not done yesterday', 0, 'Alabi Paul', '', 'Teacher', '4J', '2018-03-12 09:21:00', 'Mr. & Mrs. Olatayo', '', 'inbox', 0, 0),
(84, 'Alert', 'is sleeping in Class through-out today', 0, 'Alabi Paul', 'Adebowale Ayisat', 'Teacher', '4J', '2018-05-16 02:48:56', 'Mr. & Mrs. Adebowale', '', 'inbox', 0, 0),
(85, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-05-24 04:06:31', 'Alabi Paul', '', 'inbox', 0, 0),
(86, 'Alert', 'is sick today ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '4J', '2018-06-27 12:59:45', 'Alabi Paul', '', 'inbox', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `parent_access`
--

CREATE TABLE `parent_access` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'ACTIVE',
  `password2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_access`
--

INSERT INTO `parent_access` (`id`, `name`, `username`, `password`, `student_name`, `sex`, `status`, `password2`) VALUES
(2, 'Mr. Falemu Sunday ', 'sunnyfexx', 'password', 'ADEBAYO INIOLUWA', 'M', 'ACTIVE', ''),
(3, 'Mr. Falemu Sunday 1', 'sunnyfexx', 'oluwafemi5a04a70981e85', 'ADEBAYO INIOLUWA', 'M', 'ACTIVE', ''),
(4, 'Mr. Falemu Sunday 4', 'sunnyfexx', '82d99027f0be210b7ad4bd45d4679817', 'ADEDOSU-GOLD PEACE', 'M', 'ACTIVE', 'oluwafemi');

-- --------------------------------------------------------

--
-- Table structure for table `recovery_pass`
--

CREATE TABLE `recovery_pass` (
  `id` int(6) NOT NULL,
  `username` varchar(50) NOT NULL,
  `code` int(20) NOT NULL,
  `sent_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recovery_pass`
--

INSERT INTO `recovery_pass` (`id`, `username`, `code`, `sent_date`, `status`) VALUES
(7, 'adegbajuvictor@yahoo.com', 3032, '2018-01-07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sent`
--

CREATE TABLE `sent` (
  `id` int(11) NOT NULL,
  `title` varchar(225) NOT NULL,
  `message` text NOT NULL,
  `user_id` int(50) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `user_role` varchar(20) NOT NULL,
  `class` varchar(20) NOT NULL,
  `msg_date` datetime NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `status` text NOT NULL,
  `action1` int(11) NOT NULL,
  `action2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sent`
--

INSERT INTO `sent` (`id`, `title`, `message`, `user_id`, `sender`, `student_name`, `user_role`, `class`, `msg_date`, `receiver`, `subject`, `status`, `action1`, `action2`) VALUES
(12, 'Thanks', 'Thank you sir for great job done. More grace.', 0, 'Mr. & Mrs. Falana', '', 'Parent', '', '2017-12-17 05:56:59', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(13, 'Thanks', 'Good job sir. More grace to your palm', 0, 'Mr. & Mrs. Falana', '', 'Parent', '', '2017-12-17 06:00:37', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(14, 'thnaks sir', 'i will see to the method ', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-17 06:08:43', 'Mr. & Mrs. Falana', 'Social Studies', 'sent', 0, 0),
(15, 'This is my story', 'Whatever you send out will be in your sent item', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-17 06:24:35', 'Mr. & Mrs. Falana', 'Social Studies', 'sent', 0, 0),
(16, 'WELCOME TO A NEW MONTH', 'THNAKS', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-30 09:58:23', 'Mr. Wolekemi Dada', 'Social Studies', 'sent', 0, 0),
(17, 'WELCOME TO A NEW MONTH NOTHER', 'YES', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-30 10:13:18', 'Mr. Wolekemi Dada', 'Mathematics', 'sent', 0, 0),
(18, 'FROM SUNDAY', 'PLEASE HELP TO REVIEW THE MESSAGE', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-30 11:05:30', 'Mr. Wolekemi Dada', 'Social Studies', 'sent', 0, 0),
(19, 'WELCOME TO A NEW MONTH', 'thanks', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-30 11:11:03', 'Mr. Wolekemi Dada', 'Social Studies', 'sent', 0, 0),
(20, 'WELCOME TO A NEW MONTH', 'thanks', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-30 11:12:26', 'Mr. Wolekemi Dada', 'Social Studies', 'sent', 0, 0),
(21, 'WELCOME TO A NEW MONTH', 'thnaks', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-30 11:15:33', 'Mr. Wolekemi Dada', 'Social Studies', 'sent', 0, 0),
(22, 'WELCOME TO A NEW MONTH', 'thnkas', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-30 11:17:18', 'Mr. Wolekemi Dada', 'Social Studies', 'sent', 0, 0),
(23, 'FROM SUNDAY', 'this is a sms message', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2017-12-30 11:23:10', 'Mr. Wolekemi Dada', 'Social Studies', 'sent', 0, 0),
(24, 'WELCOME TO A NEW MONTH', 'this', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 11:26:49', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(25, 'FROM SUNDAY', 'tsdfsfsd', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 11:29:04', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(26, 'FROM SUNDAY', 'zddsa', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 11:29:53', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(27, 'FROM SUNDAY', 'ths', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 11:34:35', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(28, 'FROM SUNDAY', 'thssjsjs', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 11:34:56', 'Mr. Wolekemi Dada', 'Mathematics', 'sent', 0, 0),
(29, 'WELCOME TO A NEW MONTH', 'dsffds', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 11:36:19', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(30, 'FROM SUNDAY', 'gfdsfdsfd', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 11:57:20', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(31, 'WELCOME TO A NEW MONTH', 'this is me', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 11:59:53', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(32, 'WELCOME TO A NEW MONTH', 'fdsfsdf', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:02:41', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(33, 'WELCOME TO A NEW MONTH', 'cxzcxzc', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:06:02', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(34, 'WELCOME TO A NEW MONTH', 'xsx', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:06:52', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(35, 'WELCOME TO A NEW MONTH', 'ddd', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:07:36', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(36, 'WELCOME TO A NEW MONTH', 'ssd', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:08:05', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(37, 'WELCOME TO A NEW MONTH', 'tdsdfdsddf', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:11:40', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(38, 'WELCOME TO A NEW MONTH', 'hhhh', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:12:11', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(39, 'WELCOME TO A NEW MONTH', 'dczxc', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:12:55', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(40, 'WELCOME TO A NEW MONTH', 'dczxc', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:13:22', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(41, 'WELCOME TO A NEW MONTH', 'sdsadsad', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2017-12-30 12:13:52', 'Mr. Femi Caleb', 'Social Studies', 'sent', 0, 0),
(42, 'This is the', 'ddd', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2018-01-12 06:30:52', 'Mr and Mrs Adegbaju', '', 'sent', 0, 0),
(43, '', 'is sleeping in Class through-out today', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2018-01-12 07:34:04', 'Mr. & Mrs. Adebowale', '', 'sent', 0, 0),
(44, 'Alert', 'assignment was not done yesterday', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2018-01-12 07:35:11', 'Mr. & Mrs. Adejumo', '', 'sent', 0, 0),
(45, 'Alert', 'is sleeping in Class through-out today', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-12 07:44:13', '', '', 'sent', 0, 0),
(46, 'Alert', 'is sleeping in Class through-out today', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-12 07:44:56', '', '', 'sent', 0, 0),
(47, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-12 08:16:43', 'sunday', '', 'sent', 0, 0),
(48, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 08:35:50', 'sunday', '', 'sent', 0, 0),
(49, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 08:47:41', 'sunday', '', 'sent', 0, 0),
(50, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 08:49:33', 'sunday', '', 'sent', 0, 0),
(51, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 08:51:04', 'sunday', '', 'sent', 0, 0),
(52, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 08:53:00', 'sunday', '', 'sent', 0, 0),
(53, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 08:54:22', 'sunday', '', 'sent', 0, 0),
(54, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 08:55:49', 'sunday', '', 'sent', 0, 0),
(55, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 08:56:19', 'sunday', '', 'sent', 0, 0),
(56, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 09:02:51', 'sunday', '', 'sent', 0, 0),
(57, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 09:03:09', 'sunday', '', 'sent', 0, 0),
(58, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Femi Caleb', '', 'Teacher', '', '2018-01-13 09:05:21', 'Mr. Wolekemi Dada', '', 'sent', 0, 0),
(59, 'Alert', 'should be taken care of for adequate well being', 0, 'Mr. Wolekemi Dada', '', 'Parent', '', '2018-01-13 04:46:54', 'sunday', '', 'sent', 0, 0),
(60, 'Alert', 'is sick today in school', 0, 'sunday', '', 'Teacher', '', '2018-01-15 01:39:24', '', '', 'sent', 0, 0),
(61, 'Alert', 'should be taken care of for adequate well being', 0, 'sunday', '', 'Teacher', '', '2018-01-15 01:40:34', '', '', 'sent', 0, 0),
(62, 'Alert', 'is sleeping in Class through-out today', 0, 'sunday', '', 'Teacher', '', '2018-01-15 01:49:07', '', '', 'sent', 0, 0),
(63, 'Alert', 'should be taken care of for adequate well being', 0, 'sunday', '', 'Teacher', '', '2018-01-15 01:49:37', '', '', 'sent', 0, 0),
(64, 'Alert', 'is sleeping in Class through-out today', 0, 'sunday', '', 'Teacher', '', '2018-01-15 01:51:32', 'Mr. Wolekemi Dada', '', 'sent', 0, 0),
(65, 'Alert', 'is sick today in school', 0, 'sunday', '', 'Teacher', '', '2018-01-15 01:51:45', '', '', 'sent', 0, 0),
(66, 'Alert', 'is sick today in school', 0, 'sunday', '', 'Teacher', '', '2018-01-15 01:52:29', 'Mr. & Mrs. Adebowale', '', 'sent', 0, 0),
(67, 'Alert', 'is sleeping in Class through-out today', 0, 'sunday', '', 'Teacher', '', '2018-01-15 01:52:59', '', '', 'sent', 0, 0),
(68, 'Alert', 'assignment was not done yesterday', 0, 'Alabi Pau', '', 'Teacher', '', '2018-01-15 08:59:53', '', '', 'sent', 0, 0),
(69, 'Alert', 'is sick today ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-01-26 06:06:51', 'Alabi Paul', '', 'sent', 0, 0),
(70, 'Alert', 'is sick today ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-01-28 03:19:43', 'Alabi Paul', '', 'sent', 0, 0),
(71, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-02-15 08:55:23', 'Alabi Paul', '', 'sent', 0, 0),
(72, 'Alert', 'is sick today ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-02-15 09:15:07', 'Alabi Paul', '', 'sent', 0, 0),
(73, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-02-16 12:24:22', 'Alabi Paul', '', 'sent', 0, 0),
(74, 'Alert', 'is sick today in school', 0, 'Alabi Paul', '', 'Teacher', '', '2018-02-16 10:10:36', 'Mr. & Mrs. Adebowale', '', 'sent', 0, 0),
(75, 'Alert', 'will be travelling tomorrow ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-02-23 10:15:01', 'Alabi Paul', '', 'sent', 0, 0),
(76, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-03-08 02:32:55', 'Alabi Paul', '', 'sent', 0, 0),
(77, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-03-09 11:36:33', 'Alabi Paul', '', 'sent', 0, 0),
(78, 'Alert', 'is sleeping in Class through-out today', 0, 'Alabi Paul', '', 'Teacher', '', '2018-03-11 03:07:20', 'Mr. & Mrs. Olatayo', '', 'sent', 0, 0),
(79, 'Alert', 'assignment was not done yesterday', 0, 'Alabi Paul', '', 'Teacher', '', '2018-03-11 03:17:56', 'Mr. & Mrs. Olatayo', '', 'sent', 0, 0),
(80, 'Alert', 'assignment was not done yesterday', 0, 'Alabi Paul', '', 'Teacher', '', '2018-03-12 09:21:00', 'Mr. & Mrs. Olatayo', '', 'sent', 0, 0),
(81, 'Alert', 'is sleeping in Class through-out today', 0, 'Alabi Paul', '', 'Teacher', '', '2018-05-16 02:48:56', 'Mr. & Mrs. Adebowale', '', 'sent', 0, 0),
(82, 'Alert', 'assignment was not done yesterday', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-05-24 04:06:31', 'Alabi Paul', '', 'sent', 0, 0),
(83, 'Alert', 'is sick today ', 0, 'Mr. & Mrs. Olatayo', '', 'Parent', '', '2018-06-27 12:59:45', 'Alabi Paul', '', 'sent', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_record`
--

CREATE TABLE `student_record` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'ACTIVE',
  `date_added` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `parent_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_record`
--

INSERT INTO `student_record` (`id`, `student_name`, `sex`, `class`, `status`, `date_added`, `email`, `phone`, `parent_name`) VALUES
(502, 'Ogunlade Olabisi A.', '', '4J', 'ACTIVE', '2017-12-17', 'bolagunlade@gmail.com, o.gunlade@oau.edu.ng', '08052236423, 07038540564', 'Dr. O. Ogunlade'),
(503, 'Adejuwon Iorun', '', '4J', 'ACTIVE', '2017-12-17', '', '08066088833', 'Mr. Adejuwon'),
(504, 'Okoroafor Chidima', '', '4J', 'ACTIVE', '2017-12-17', '', '08030401725', 'Mrs. P.A. Philomina Okoroafor'),
(505, 'Awoyele Samuel', '', '4J', 'ACTIVE', '2017-12-17', '', '08035031980, 07033495405', 'Mr. Awoyele '),
(506, 'Adebisi Jolaade Merit', '', '4J', 'ACTIVE', '2017-12-17', '', '08055914808, 07062064407', 'Mr. M.O. Adebisi'),
(507, 'Eme Destiny', '', '4J', 'ACTIVE', '2017-12-17', '', '07064874660', 'Rev. Eme Okon'),
(508, 'Oyedokun Alfred', '', '4J', 'ACTIVE', '2017-12-17', '', '08061301955', 'Mr. Oyedokun'),
(509, 'Ogundana Wilson Olukayode', '', '4J', 'ACTIVE', '2017-12-17', '', '08137217978', 'Ogundana Charleson Olukayode'),
(510, 'Odewande Racheal', '', '4J', 'ACTIVE', '2017-12-17', '', '08038506417', 'Mr. Odewande '),
(511, 'Afolabi Eohraim', '', '4J', 'ACTIVE', '2017-12-17', '', '07038195748', 'Mr. Afolabi'),
(512, 'Akinlade Tolulope M.', '', '4J', 'ACTIVE', '2017-12-17', 'lekamofe@yahoo.com', '8137707632', 'Mr. & Mrs. M.O. Akinlade'),
(513, 'Adedokun Odunayo', '', '4J', 'ACTIVE', '2017-12-17', 'rufusadedokun22@yahoo.com', '08033628249, 08067236171', 'Mr. Adedokun'),
(514, 'Akintude Anuoluwa', '', '4J', 'ACTIVE', '2017-12-17', 'olushey99@gmail.com', '08035369934, 07066186962', 'Mr. Gbeminiyi Akintude'),
(515, 'Oyedeji Oluwafemi', '', '4J', 'ACTIVE', '2017-12-17', 'olaoluoyedeji@gmail.com', '08033745381', 'Mr. O. Oyedeji'),
(516, 'Dada Oluwafeyikemi', '', '4J', 'ACTIVE', '2017-12-17', 'wourlus@gmail.com', '07033281680, 08037774075', 'Mr. Wolekemi Dada'),
(517, 'Olatayo Mabel', '', '4J', 'ACTIVE', '2017-12-17', 'eniita01@yahoo.co.uk', '08032453815, 07035698070', 'Mr. & Mrs. Olatayo'),
(518, 'Omidiji Ayomikun', '', '4J', 'ACTIVE', '2017-12-17', 'bomidiji@oauife.edu.ng', '08025565252, 08171790442', 'Dr. & Mrs. Victor Omidiji'),
(519, 'Bamigboye Oluwatobi', '', '4J', 'ACTIVE', '2017-12-17', 'bamigboyeadebola@yahoo.com', '08139345751, 08168746840', 'Dr. & Mrs. Bamigboye '),
(520, 'Famuyiwa Abigael', '', '4J', 'ACTIVE', '2017-12-17', '', '08166020238', 'Dr. & Dr. (Mrs.) Famuyiwa'),
(521, 'Fasanya Ninunlola', '', '4K', 'ACTIVE', '2017-12-17', 'posifasanya@gmail.com', '08033802431, 08063890822', 'Mr. Fasanya John Olaposi'),
(522, 'Falana Olufolabi', '', '4K', 'ACTIVE', '2017-12-17', 'folafemi2030@gmail.com', '08034635029, 08034650216', 'Mr. & Mrs. Falana'),
(523, 'Lawal Abdulmalik', '', '4K', 'ACTIVE', '2017-12-17', 'lawalyemisi98@yahoo.com', '07031943020, 07061360419', 'Mr. & Mrs.  Lawal'),
(524, 'Adebowale Ayisat', '', '4K', 'ACTIVE', '2017-12-17', 'femifalemu@gmail.com', '08162637500', 'Mr. & Mrs. Adebowale'),
(525, 'Fasanya Didunlola', '', '4K', 'ACTIVE', '2017-12-17', '', '', 'Mr. & Mrs. Fasanya '),
(526, 'Olagunju Iyanu', '', '4K', 'ACTIVE', '2017-12-17', 'rayolagunju73@gmail.com', '07034249212, 08039116485', 'Mr. & Mrs. Olagunju'),
(527, 'Adewoyin Daniel Adedeji', '', '4K', 'ACTIVE', '2017-12-17', 'femiadewoyin@gmail.com', '08037693543', 'Adewoyin Adefemi Abiola'),
(528, 'Ogundijo Adesewa O.', '', '4K', 'ACTIVE', '2017-12-17', 'novdnnovdchambers@yahoo.com', '07031277008, 08068997426', 'Barrister & Mrs. Ogundijo'),
(529, 'Adebayo Adedamola Victoria', 'male', '4K', 'ACTIVE', '2018-01-06', 'femifalemu@gmail.com', '08055301958, 07030059659', 'Mr. & Mrs. A.S. Adebayo'),
(530, 'Olaleye Antonia', '', '4K', 'ACTIVE', '2017-12-17', 'modupeoleleye98@yahoo.com', '08034088361, 08034088933', 'Mr. & Mrs. Olaleye'),
(531, 'Akindoyin Iseoluwa', 'male', '4K', 'ACTIVE', '2018-01-06', 'sunnyfexx1@yahoo.com', '08182458806, 09029628941', 'Mr. & Mrs. Akindoyin'),
(532, 'Ayodele Omotewa', '', '4K', 'ACTIVE', '2017-12-17', 'olabisiayodele@gmail.com', '08034991621, 08034268849', 'Mr. & Mrs. Ayodele'),
(533, 'Bolaji Aliyat', '', '4K', 'ACTIVE', '2017-12-17', '', '08035736922', 'Mr. & Mrs. Bolaji'),
(534, 'Raji Fatimoh', '', '4K', 'ACTIVE', '2017-12-17', 'legacysen_subuib@yahoo.com', '07030590266', 'Mr. & Mrs. Raji'),
(535, 'Sumibola Deborah', '', '4K', 'ACTIVE', '2017-12-17', 'olororosentebenezer@yahoo.com', '08067656109, 08038606192', 'Mr. & Mrs. Sumibola'),
(536, 'Adeolu Loveth', '', '4K', 'ACTIVE', '2017-12-17', 'salesng@vistafrica.net', '08032520850', 'Mr. & Mrs. Adeolu '),
(537, 'Afolabi Omolewa Amanda', '', '4K', 'ACTIVE', '2017-12-17', 'aofolabi@aouife.edu.ng, aoafolabi@yahoo.com', '08067893431, 07036120269', 'Mr. & Mrs. O. Afolabi'),
(538, 'Baidoo Edward', '', '4K', 'ACTIVE', '2017-12-17', 'blanskonbaidoo@gmail.com', '08062564660, 08038289432', 'Baidoo Bonny Blanskon'),
(539, 'Oladodun Caleb', '', '4K', 'ACTIVE', '2017-12-17', 'tundeoladokun@yahoo.com', '07030060097', 'Dr. Tunde Oladokun'),
(540, 'Emannuel Didaraloluwa', '', '4K', 'ACTIVE', '2017-12-17', 'olugbengaemmanuel@', '08034349242, 08034855569', 'Emmanuel O.G.'),
(541, 'Olatinwo Ishaq', '', '4L', 'ACTIVE', '2017-12-17', 'solakunle711@yahoo.com', '07031355026, 08136785446', 'Mr. & Mrs. Olatinwo '),
(542, 'Akinyele Samuel', '', '4L', 'ACTIVE', '2017-12-17', 'istrel@yahoo.com', '08033669892, 07032185084', 'Mr. & Mrs. Akinyele'),
(543, 'Lateef Basit', '', '4L', 'ACTIVE', '2017-12-17', '', '08094355245, 08033955817', 'Mr. & Mrs. Lateef'),
(544, 'Oyatomi Precious', '', '4L', 'ACTIVE', '2017-12-17', '', '08032756220', 'Mr. & Mrs. Oyatomi'),
(545, 'Ajagbe Semilogo', '', '4L', 'ACTIVE', '2017-12-17', '', '08035629326, 08034098707', 'Mr. & Mrs. Ajagbe'),
(546, 'Oyelowo Aishat', '', '4L', 'ACTIVE', '2017-12-17', 'jubriloyelowo@gmail.com', '08050575300', 'Mr. & Mrs. Oyelowo'),
(547, 'Adebowale Ajarat', '', '4L', 'ACTIVE', '2017-12-17', '', '08162537500', 'Mr. & Mrs. Adebowale'),
(548, 'Ajayi Amoluwa', '', '4L', 'ACTIVE', '2017-12-17', '', '08035625962, 07032477617', 'Dr. & Mrs. Ajayi'),
(549, 'Oladepo Ganiyat', '', '4L', 'ACTIVE', '2017-12-17', '', '08033573831', 'Mr. & Mrs. Oladepo'),
(550, 'Adebowale Aminat', '', '4L', 'ACTIVE', '2017-12-17', '', '08162637500', 'Mr. & Mrs. Adebowale'),
(551, 'Tchokossa Jessica', '', '4L', 'ACTIVE', '2017-12-17', '', '08033867749', 'Dr. & Mrs. Tchokossa'),
(552, 'Okunmakinde Ibukun', '', '4L', 'ACTIVE', '2017-12-17', '', '08057975422', 'Mr. & Mrs. Okunmakinde'),
(553, 'Olaifa Akintayo', '', '4M', 'ACTIVE', '2017-12-17', 'waleolaifa24@yahoo.com', '07038098949', 'Adebowale A. Olaifa'),
(554, 'Adejumo Anthony', '', '4M', 'ACTIVE', '2017-12-17', '', '07030988681, 0806282031', 'Mr. & Mrs. Adejumo'),
(555, 'Owolabi Oluwajomiloju', '', '4M', 'ACTIVE', '2017-12-17', '', '08039187261, 07038015747', 'Mr. & Mrs. Owolabi'),
(556, 'Oseghale Deught', '', '4M', 'ACTIVE', '2017-12-17', 'oseghale2006@yahoo.co.uk', '08067855731, 08035744713', 'Oseghale Godwin'),
(557, 'Falola Samuel', '', '4M', 'ACTIVE', '2017-12-17', '', '08033885862, 09092967085', 'Mr. & Mrs. Falola'),
(558, 'Abidoye Joshua', '', '4M', 'ACTIVE', '2017-12-17', 'abidoye2007@gmail.com', '08034243553, 08034243493', 'Mr. Mrs. Abidoye'),
(559, 'Agboola Olamidotun', '', '4M', 'ACTIVE', '2017-12-17', 'bosede2k6@yahoo.co.uk', '08065210041', 'Dr. & Mrs. A.F. Agboola'),
(560, 'Ademuleya Seyi', '', '4M', 'ACTIVE', '2017-12-17', 'sehindeademuleya@yahoo.com', '08023537484, 08121329270', 'Dr. & Mrs. Ademuleya'),
(561, 'Omissakin Funmilayo', '', '4M', 'ACTIVE', '2017-12-17', '', '08060412003, 08146827988', 'Omisakin Ola-Olu'),
(562, 'Idowu Akinyinka Favour', '', '4M', 'ACTIVE', '2017-12-17', '', '08062698343, 08062600607', 'Mr. & Mrs. Idowu F.A.'),
(563, 'Diyaolu Moyinoluwa', '', '4M', 'ACTIVE', '2017-12-17', '', '08037442858', 'Dr. & Mrs. Diyaolu'),
(564, 'Adediran Adeola', '', '4M', 'ACTIVE', '2017-12-17', '', '07039019981', 'Mr. & Mrs. Adediran'),
(565, 'Omenyi Cleopatra Pelumi', '', '4M', 'ACTIVE', '2017-12-17', 'yhemmycp@gmail.com', '08167735949', 'Mr. & Mrs. Oloka'),
(566, 'Omotayo Femi Feranmi', '', '4M', 'ACTIVE', '2017-12-17', '', '08036404112', 'Mr. & Mrs. Omotayo'),
(567, 'Olaleye Joel Aseoluwa', '', '4M', 'ACTIVE', '2017-12-17', 'lanreolaleye403@yahoo.com, victoriaolasux@gmail.co', '07035570884, 08032258056', 'Dr. & Mrs. P.O. Olaleye'),
(568, 'Adesola Iyanuoluwa', '', '4N', 'ACTIVE', '2017-12-17', 'fadesola@oauife.edu.ng', '08034025067, 08034233894', 'Prof. & Mrs. Funso Adesola'),
(569, 'Olatunde Blessing', '', '4N', 'ACTIVE', '2017-12-17', 'olatundefaith18@yahoo.com', '08033678223, 08036210254', 'Mr. & Mrs. Olatunde'),
(570, 'Egbula Paul', '', '4N', 'ACTIVE', '2017-12-17', '', '08060103593, 08034774976', 'Mr. & Mrs. Egbula'),
(571, 'Adelooye Omobadewa', '', '4N', 'ACTIVE', '2017-12-17', '', '08063751158, 08062580178', 'Mr. & Mrs. Adelooye'),
(572, 'Adebayo Inioluwa', '', '4N', 'ACTIVE', '2017-12-17', '', '08055752063', 'Mr. & Mrs. Adebayo'),
(573, 'Oyesoji Israel', '', '4N', 'ACTIVE', '2017-12-17', '', '08034672789, 08134571055', 'Mr. & Mrs. Oyesoji'),
(574, 'Adigun Ayojesu', '', '4N', 'ACTIVE', '2017-12-17', 'folakemiibukun@gmail.com', '08036679691', 'Mrs. Adigun Oluwafolakemi'),
(575, 'Ebeagu Chidima', '', '4N', 'ACTIVE', '2017-12-17', 'ebeagut@gmail.com', '08037151287', 'Ebeagu, Thomas'),
(576, 'Fadiran Debora Olapeju', '', '4N', 'ACTIVE', '2017-12-17', 'fadiranolayinka@yahoo.com', '08067435642', 'Mr. & Mrs. Fadiran'),
(577, 'Meadows Ifejesu', '', '4N', 'ACTIVE', '2017-12-17', 'chrisbo155mc@gmail.com', '08033779627', 'Mr. & Mrs. Meadows C.B. '),
(578, 'Adenuga Fiyikoluwa Gloria', '', '4N', 'ACTIVE', '2017-12-17', 'adenuga@gmail.com', '08112645950, 0811294791', 'Mr. & Mrs. Adenuga'),
(579, 'Adekanye Kehinde ', '', '4N', 'ACTIVE', '2017-12-17', 'adekanyesamuel.com', '08035875422', 'Mr. & Mrs. Adekanye'),
(580, 'Adedosu Gold-Peace', '', '4N', 'ACTIVE', '2017-12-17', 'chrisade@gmail.com ', '08137989377, 08061528276', 'Mr. & Mrs. Adedosu'),
(581, 'Makinde Jesufemi', '', '4N', 'ACTIVE', '2017-12-17', 'mummyzronkeomoola@yahoo.com, makinde_abidemi@yahoo', '08033155867, 08068039551', 'Dr. Mainde'),
(582, '', '', '', 'ACTIVE', '2017-12-17', '', '', ''),
(583, 'Babafemi Oluwaseun', '', '5J', 'ACTIVE', '2017-12-17', 'dewunmi2001@yahoo.com', '8033930160', 'Dr and Mrs Babafemi '),
(584, 'Asahiah Araoluwa', '', '5J', 'ACTIVE', '2017-12-17', 'asahiahkemi@gmail.com', '08067033662', 'Mr and Mrs Asahiah'),
(585, 'Adewoyin Adenike Dorcas', '', '5J', 'ACTIVE', '2017-12-17', 'gigantic432@yahoo.com', '08158209575', 'Mr and Mrs Adewoyin'),
(586, 'Adejumobi Ireoluwa', '', '5J', 'ACTIVE', '2017-12-17', 'adejumobiireoluwa@gmail.com', '08101818465', 'Revd and Mrs Kemi Adejumobi'),
(587, 'Olafare Moyinoluwa', '', '5J', 'ACTIVE', '2017-12-17', '', '08072599024', 'Mr and Mrs Olafare'),
(588, 'Adegoke Adebola', '', '5J', 'ACTIVE', '2017-12-17', '', '08034064170', 'Mr and Mrs Adegoke'),
(589, 'Olokunboro Best', '', '5J', 'ACTIVE', '2017-12-17', '', '08034712330', 'Mr and Mrs Olokunboro'),
(590, 'Adeyemo Wisdom', '', '5J', 'ACTIVE', '2017-12-17', 'crownfitchild2012@gmail.com', '07033262157', 'Mr and Mrs Adeyemo'),
(591, 'Adeyefa Boluwatife', '', '5J', 'ACTIVE', '2017-12-17', 'adeyefaoladunni@gmail.com', '08136682172', 'Mr and Mrs Adeyefa'),
(592, 'Jedege Korede', '', '5J', 'ACTIVE', '2017-12-17', 'pojedege@gmail.com', '08137445405', 'Mr and Mrs Jedege'),
(593, 'Adeleke Sharon', '', '5J', 'ACTIVE', '2017-12-17', 'aygold10@gmail.com', '08060876043', 'Dr and Mrs Adeleke'),
(594, 'Olagunju Praise', '', '5J', 'ACTIVE', '2017-12-17', 'olagunjupraise@gmail.com', '08035605885', 'Mr and Mrs Olagunju'),
(595, 'Eludoyin Eludamola', '', '5J', 'ACTIVE', '2017-12-17', '', '08034089615', 'Mr and Mrs Eludoyin'),
(596, 'Adelekan Adesewa', '', '5J', 'ACTIVE', '2017-12-17', '', '08038033650', 'Mr and Mrs Adelekan'),
(597, 'Gbenle Daniel', '', '5J', 'ACTIVE', '2017-12-17', '', '07062392134', 'Mr and Mrs Gbenle'),
(598, 'Adeyosoye Faviour', '', '5J', 'ACTIVE', '2017-12-17', 'sojodex@yahoo.com', '08075458120', 'Mr and Mrs Adeyosoye'),
(599, 'Akinola Oluwaferanmi', '', '5J', 'ACTIVE', '2017-12-17', 'kolawoleia73@gmail.com', '08039401534', 'Mr and Mrs Akinola'),
(600, 'Odewande Joseph', '', '5J', 'ACTIVE', '2017-12-17', '', '08038506417', 'Mr and Mrs Odewande'),
(601, 'Balogun Oluwabukunmi', '', '5J', 'ACTIVE', '2017-12-17', 'gajicious@gmail.com', '08056679439', 'Mr and Mrs Balogun'),
(602, 'Mogaji Dolapo', '', '5J', 'ACTIVE', '2017-12-17', 'gajicious@gmail.com', '07062709767', 'Mr and Mrs Mogaji'),
(603, 'Adewale Adetomiwa', '', '5L', 'ACTIVE', '2017-12-17', 'adewaleadeleke62@gmail.com', '07068949242', 'Mr and Mrs Adewale'),
(604, 'Arabi Taiwo', '', '5L', 'ACTIVE', '2017-12-17', '', '07064976647', 'Mr and Mrs Arabi '),
(605, 'Oyedeji Prisilla', '', '5L', 'ACTIVE', '2017-12-17', '', '08037021099', 'Mr and Mrs Oyedeji'),
(606, 'Mosobalaje Aramide', '', '5L', 'ACTIVE', '2017-12-17', '', '08032104379', 'Mr and Mrs Mosobalaje'),
(607, 'Adesoji Faith', '', '5L', 'ACTIVE', '2017-12-17', '', '08033694245', 'Rev and Mrs Adesoji'),
(608, 'Banjo Grace', '', '5L', 'ACTIVE', '2017-12-17', 'drmrsbanjo@gmail.com', '08039267241', 'Mr and Mrs Banjo'),
(609, 'Faronbi Isreal', '', '5L', 'ACTIVE', '2017-12-17', '', '08033383018', 'Mr and Mrs Faronbi'),
(610, 'Falowo Abudulafeez', '', '5L', 'ACTIVE', '2017-12-17', 'femifalowo@gmail.com', '08064233921', 'Mr and Mrs Falowo'),
(611, 'Ibrahim Muhammad', '', '5L', 'ACTIVE', '2017-12-17', '', '08052124965', 'Mr and Mrs Ibrahim'),
(612, 'Akano Aishat', '', '5L', 'ACTIVE', '2017-12-17', 'akano@yahoo.com', '08039280494', 'Mr and Mrs Akano'),
(613, 'Olawoyin Muniroh', '', '5L', 'ACTIVE', '2017-12-17', '', '08035230872', 'Mr and Mrs Olawoyin'),
(614, 'Adegbenjo Testimony', '', '5L', 'ACTIVE', '2017-12-17', 'adetunjiadegbenjo@yahoo.com', '07038097118', 'Mr and Mrs Adegbenjo'),
(615, 'Ogunba Oluwagbola', '', '5L', 'ACTIVE', '2017-12-17', 'segogunba@gmail.com', '08043014739', 'Prof. and Dr Mrs Ogunba'),
(616, 'Adeyeye Grace', '', '5L', 'ACTIVE', '2017-12-17', '', '08034401502', 'Mr and Mrs Adeyeye'),
(617, 'Adisa Abdulrazaaq', '', '5L', 'ACTIVE', '2017-12-17', '', '', 'Mr and Mrs Adisa'),
(618, 'Mustapha Naphesat', '', '5L', 'ACTIVE', '2017-12-17', 'el-mustapha@gmail.com', '08030667583', 'Mr and Mrs Mustapha'),
(619, 'Arilewola Mercy', '', '5L', 'ACTIVE', '2017-12-17', 'arilewolamoses16@gmail.com', '07033301487', 'Mr and Mrs Arilewola'),
(620, 'Ganiyu Kareemot', '', '5L', 'ACTIVE', '2017-12-17', '', '08034163618', 'Mr and Mrs Ganiyu'),
(621, 'Eludoyin Oladokun', '', '5L', 'ACTIVE', '2017-12-17', '', '09051715499', 'Mr and Mrs Eludoyin'),
(622, 'Folarin Kamil', '', '5L', 'ACTIVE', '2017-12-17', 'fprecious@yahoo.com', '08062605862', 'Mr and Mrs Folarin'),
(623, 'Arabi Kehinde', '', '4K', 'ACTIVE', '2017-12-17', '', '07064976647', 'Mr and Mrs Arabi '),
(624, 'Adekunle Favour', 'male', '4K', 'ACTIVE', '2018-01-06', 'sunnyfexx@gmail.com', '08037877772', 'Mr and Mrs Adekunle'),
(625, 'Adegbaju Adedolapo', 'male', '4K', 'ACTIVE', '2018-01-07', 'adegbajuvictor@yahoo.com', '08067367726', 'Mr and Mrs Adegbaju'),
(626, 'Awoleye David', '', '4K', 'ACTIVE', '2017-12-17', 'awoleye@yahoo.co.uk', '07069197823', 'Mr and Mrs Awoleye'),
(627, 'Akingbesote Olajumoke', '', '4K', 'ACTIVE', '2017-12-17', '', '08169775323', 'Mr and Mrs Akingbesote'),
(628, 'Oyelese Isaac', '', '4K', 'ACTIVE', '2017-12-17', 'oyelese2002@yahoo.com', '08035822534', 'Mr and Mrs Oyelese'),
(629, 'Faleye Joy', '', '4K', 'ACTIVE', '2017-12-17', 'folakefaleye@yahoo.com', '07069412346', 'Mr and Mrs Faleye'),
(630, 'Baloye Oluwaseun', '', '4K', 'ACTIVE', '2017-12-17', 'davidithebeloved@gmail.com', '08034416567', 'Mr and Mrs Baloye'),
(631, 'Ojo Ololade', 'female', '4K', 'ACTIVE', '2018-01-22', 'ololade', '08069307178', 'Mr and Mrs Ojo'),
(632, 'Henry Aderinoye', '', '4K', 'ACTIVE', '2017-12-17', '', '08035033880', 'Mr and Mrs Ijaware'),
(633, 'Odekanyin Temiloluwa', '', '4K', 'ACTIVE', '2017-12-17', 'deleodekanyin@yahoo.co.uk', '08062879457', 'Mr and Mrs Odekanyin '),
(634, 'Ayoola Gideon', '', '4K', 'ACTIVE', '2017-12-17', 'oayoola@oau.edu.ng', '08060149097', 'Mr and Mrs Ayoola'),
(635, 'Omisakin Emmanuel', '', '4K', 'ACTIVE', '2017-12-17', '', '08146827988', 'Mr and Mrs Omisakin'),
(636, 'Baidoo Mercy', '', '4K', 'ACTIVE', '2017-12-17', 'bonnyblankson@gmail.com', '08038289432', 'Mr and Mrs Baidoo'),
(637, 'Elubanji Omogbolahan', 'male', '4K', 'ACTIVE', '2018-01-06', 'todox4real@gmail.com', '08065007232', 'Mr.& Mrs. Elubanji'),
(673, 'Fodeke Inioluwa', 'F', '6J', 'ACTIVE', '2018-02-15', 'afodeke@yahoo.co.uk', '08053949131, 07083519273', 'Dr. & Mrs. Fodeke A.A.'),
(674, 'Oluwatope Ojurereoluwa', 'F', '6J', 'ACTIVE', '2018-02-15', 'omolayooluwatope@gmail.com', '08035962506, 08131048483', 'Dr. & Mrs. A.O. Oluwatope'),
(675, 'Okonji Raphael', 'F', '6J', 'ACTIVE', '2018-02-15', 'okonjire@yahoo.co.uk', '08060164991, 08064576027', 'Dr. & Mrs. R.E. Okonji'),
(676, 'Hamed Ayodele O.', 'M', '6J', 'ACTIVE', '2018-02-15', 'delehamedjnr@yahoo.com', '8106138260', 'Mrs. I. Hamed'),
(677, 'Eyenla Grace', 'F', '6J', 'ACTIVE', '2018-02-15', 'adesiyaneyenla@gmail.com ', '07062879561, 07060486610', 'Oba & Olori Eyenla'),
(678, 'Opadere Tijesu', 'F', '6J', 'ACTIVE', '2018-02-15', '', '08171736565, 07062652992', 'Dr. & Dr. (Mrs.) Opadere'),
(679, 'Mbah Chidera', 'F', '6J', 'ACTIVE', '2018-02-15', 'jonamengr@yahoo.co.uk', '08060779377, 07033934861', 'Mr. & Mrs. Mbah'),
(680, 'Eziyi Promise Esther', 'F', '6J', 'ACTIVE', '2018-02-15', 'eziyibest@gmail.com', '7033958606', 'Mr. Amogu Kalu Eziyi'),
(681, 'Sowande Jesutofunmi', 'M', '6J', 'ACTIVE', '2018-02-15', 'oasowande@gmail.com', '08037153008, 08060037213', 'Mr. & Mrs. Sowande'),
(682, 'Fatufe Adeife', 'M', '6J', 'ACTIVE', '2018-02-15', 'aafatufe@oauife.edu.ng', '8034450590', 'Fatufe A.A.'),
(683, 'Adebambo Oyinkansola', 'M', '6J', 'ACTIVE', '2018-02-15', 'adebanbo@gmail.com', '08035064430, 08034246318', 'Atilola & Olusoga Adebanbo'),
(684, 'Adewuyi Anuoluwapo', 'M', '6J', 'ACTIVE', '2018-02-15', 'romok@gmail.com', '08060531506, 08055602799', 'Dr. & Mrs. Adewuyi'),
(685, 'Akamo Darasimi', 'M', '6J', 'ACTIVE', '2018-02-15', 'shopey01@yahoo.co.uk', '07030171933, 07069235435', 'Mr. & Mrs. Akamo'),
(686, 'Oni Monireti Oluwaseun', 'M', '6J', 'ACTIVE', '2018-02-15', 'peteroni939@gmail.com', '08033567412, 09037531148', 'Mr. & Mrs. Oni'),
(687, 'Akinjokun Pipeloluwa', 'M', '6J', 'ACTIVE', '2018-02-15', 'adebolakinjoks@gmail.com ', '8069090287', 'Mr. & Mrs. Adesina Akinjokun'),
(688, 'Oluwaleye David', 'M', '6J', 'ACTIVE', '2018-02-15', 'issacidowu2002@yahoo.co.uk ', '08034403129, 08038931816', 'Mr. & Mrs. Oluwalye'),
(689, 'Ogedegbe Salewa', 'M', '6J', 'ACTIVE', '2018-02-15', 'chatwithrhanky7@gmail.com', '08038295855, 08034068786', 'TPL & Mrs. Ogedengbe');

-- --------------------------------------------------------

--
-- Table structure for table `student_result`
--

CREATE TABLE `student_result` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `test_score` varchar(50) NOT NULL,
  `exam_score` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `term` varchar(50) NOT NULL,
  `session` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_result`
--

INSERT INTO `student_result` (`id`, `student_name`, `subject`, `test_score`, `exam_score`, `position`, `class`, `term`, `session`) VALUES
(5, 'Fasanya Ninunlola', 'Social Studies', '28', '52', '', '4K', '1st', '2016/2017'),
(7, 'Okoroafor Chidima', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(8, 'Awoyele Samuel', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(9, 'Adebisi Jolaade Merit', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(10, 'Eme Destiny', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(11, 'Oyedokun Alfred', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(12, 'Ogundana Wilson Olukayode', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(13, 'Odewande Racheal', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(14, 'Afolabi Eohraim', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(15, 'Akinlade Tolulope M.', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(16, 'Adedokun Odunayo', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(17, 'Akintude Anuoluwa', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(18, 'Oyedeji Oluwafemi', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(19, 'Dada Oluwafeyikemi', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(20, 'Olatayo Mabel', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(21, 'Omidiji Ayomikun', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(22, 'Bamigboye Oluwatobi', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(23, 'Famuyiwa Abigael', 'Social Studies', '28', '52', '', '4J', '1st', '2016/2017'),
(24, 'Ogunlade Olabisi A.', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(25, 'Adejuwon Iorun', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(26, 'Okoroafor Chidima', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(27, 'Awoyele Samuel', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(28, 'Adebisi Jolaade Merit', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(29, 'Eme Destiny', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(30, 'Oyedokun Alfred', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(31, 'Ogundana Wilson Olukayode', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(32, 'Odewande Racheal', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(33, 'Afolabi Eohraim', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(34, 'Akinlade Tolulope M.', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(35, 'Adedokun Odunayo', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(36, 'Akintude Anuoluwa', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(37, 'Oyedeji Oluwafemi', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(38, 'Dada Oluwafeyikemi', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(39, 'Olatayo Mabel', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(40, 'Omidiji Ayomikun', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(41, 'Bamigboye Oluwatobi', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(42, 'Famuyiwa Abigael', '84', '24', '60', '', 'B.K', '1st', '2016/2017'),
(43, 'Ogunlade Olabisi A.', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(44, 'Adejuwon Iorun', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(45, 'Okoroafor Chidima', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(46, 'Awoyele Samuel', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(47, 'Adebisi Jolaade Merit', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(48, 'Eme Destiny', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(49, 'Oyedokun Alfred', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(50, 'Ogundana Wilson Olukayode', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(51, 'Odewande Racheal', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(52, 'Afolabi Eohraim', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(53, 'Akinlade Tolulope M.', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(54, 'Adedokun Odunayo', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(55, 'Akintude Anuoluwa', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(56, 'Oyedeji Oluwafemi', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(57, 'Dada Oluwafeyikemi', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(58, 'Olatayo Mabel', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(59, 'Omidiji Ayomikun', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(60, 'Bamigboye Oluwatobi', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(61, 'Famuyiwa Abigael', 'B.K', '24', '60', '', '4J', '1st', '2016/2017'),
(62, 'Ogunlade Olabisi A.', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(63, 'Adejuwon Iorun', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(64, 'Okoroafor Chidima', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(65, 'Awoyele Samuel', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(66, 'Adebisi Jolaade Merit', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(67, 'Eme Destiny', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(68, 'Oyedokun Alfred', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(69, 'Ogundana Wilson Olukayode', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(70, 'Odewande Racheal', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(71, 'Afolabi Eohraim', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(72, 'Akinlade Tolulope M.', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(73, 'Adedokun Odunayo', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(74, 'Akintude Anuoluwa', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(75, 'Oyedeji Oluwafemi', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(76, 'Dada Oluwafeyikemi', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(77, 'Olatayo Mabel', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(78, 'Omidiji Ayomikun', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(79, 'Bamigboye Oluwatobi', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(80, 'Famuyiwa Abigael', 'Yoruba', '28', '65', '', '4J', '1st', '2016/2017'),
(81, 'Ogunlade Olabisi A.', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(82, 'Adejuwon Iorun', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(83, 'Okoroafor Chidima', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(84, 'Awoyele Samuel', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(85, 'Adebisi Jolaade Merit', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(86, 'Eme Destiny', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(87, 'Oyedokun Alfred', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(88, 'Ogundana Wilson Olukayode', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(89, 'Odewande Racheal', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(90, 'Afolabi Eohraim', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(91, 'Akinlade Tolulope M.', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(92, 'Adedokun Odunayo', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(93, 'Akintude Anuoluwa', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(94, 'Oyedeji Oluwafemi', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(95, 'Dada Oluwafeyikemi', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(96, 'Olatayo Mabel', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(97, 'Omidiji Ayomikun', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(98, 'Bamigboye Oluwatobi', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(99, 'Famuyiwa Abigael', 'Computer', '24', '64', '', '4J', '1st', '2016/2017'),
(100, 'Ogunlade Olabisi A.', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(101, 'Adejuwon Iorun', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(102, 'Okoroafor Chidima', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(103, 'Awoyele Samuel', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(104, 'Adebisi Jolaade Merit', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(105, 'Eme Destiny', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(106, 'Oyedokun Alfred', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(107, 'Ogundana Wilson Olukayode', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(108, 'Odewande Racheal', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(109, 'Afolabi Eohraim', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(110, 'Akinlade Tolulope M.', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(111, 'Adedokun Odunayo', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(112, 'Akintude Anuoluwa', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(113, 'Oyedeji Oluwafemi', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(114, 'Dada Oluwafeyikemi', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(115, 'Olatayo Mabel', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(116, 'Omidiji Ayomikun', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(117, 'Bamigboye Oluwatobi', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(118, 'Famuyiwa Abigael', 'Computer Science', '24', '64', '', '4J', '1st', '2016/2017'),
(157, 'Ogunlade Olabisi A.', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(158, 'Adejuwon Iorun', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(159, 'Okoroafor Chidima', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(160, 'Awoyele Samuel', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(161, 'Adebisi Jolaade Merit', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(162, 'Eme Destiny', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(163, 'Oyedokun Alfred', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(164, 'Ogundana Wilson Olukayode', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(165, 'Odewande Racheal', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(166, 'Afolabi Eohraim', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(167, 'Akinlade Tolulope M.', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(168, 'Adedokun Odunayo', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(169, 'Akintude Anuoluwa', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(170, 'Oyedeji Oluwafemi', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(171, 'Dada Oluwafeyikemi', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(172, 'Olatayo Mabel', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(173, 'Omidiji Ayomikun', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(174, 'Bamigboye Oluwatobi', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(175, 'Famuyiwa Abigael', 'Science', '27', '60', '', '4J', '1st', '2016/2017'),
(251, 'Ogunlade Olabisi A.', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(252, 'Adejuwon Iorun', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(253, 'Okoroafor Chidima', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(254, 'Awoyele Samuel', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(255, 'Adebisi Jolaade Merit', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(256, 'Eme Destiny', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(257, 'Oyedokun Alfred', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(258, 'Ogundana Wilson Olukayode', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(259, 'Odewande Racheal', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(260, 'Afolabi Eohraim', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(261, 'Akinlade Tolulope M.', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(262, 'Adedokun Odunayo', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(263, 'Akintude Anuoluwa', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(264, 'Oyedeji Oluwafemi', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(265, 'Dada Oluwafeyikemi', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(266, 'Olatayo Mabel', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(267, 'Omidiji Ayomikun', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(268, 'Bamigboye Oluwatobi', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(269, 'Famuyiwa Abigael', 'English ', '25', '55', '', '4J', '1st', '2016/2017'),
(289, 'Ogunlade Olabisi A.', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(290, 'Adejuwon Iorun', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(291, 'Okoroafor Chidima', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(292, 'Awoyele Samuel', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(293, 'Adebisi Jolaade Merit', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(294, 'Eme Destiny', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(295, 'Oyedokun Alfred', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(296, 'Ogundana Wilson Olukayode', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(297, 'Odewande Racheal', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(298, 'Afolabi Eohraim', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(299, 'Akinlade Tolulope M.', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(300, 'Adedokun Odunayo', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(301, 'Akintude Anuoluwa', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(302, 'Oyedeji Oluwafemi', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(303, 'Dada Oluwafeyikemi', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(304, 'Olatayo Mabel', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(305, 'Omidiji Ayomikun', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(306, 'Bamigboye Oluwatobi', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(307, 'Famuyiwa Abigael', 'Friench', '24', '50', '', '4J', '1st', '2016/2017'),
(308, 'Ogunlade Olabisi A.', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(309, 'Adejuwon Iorun', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(310, 'Okoroafor Chidima', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(311, 'Awoyele Samuel', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(312, 'Adebisi Jolaade Merit', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(313, 'Eme Destiny', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(314, 'Oyedokun Alfred', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(315, 'Ogundana Wilson Olukayode', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(316, 'Odewande Racheal', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(317, 'Afolabi Eohraim', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(318, 'Akinlade Tolulope M.', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(319, 'Adedokun Odunayo', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(320, 'Akintude Anuoluwa', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(321, 'Oyedeji Oluwafemi', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(322, 'Dada Oluwafeyikemi', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(323, 'Olatayo Mabel', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(324, 'Omidiji Ayomikun', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(325, 'Bamigboye Oluwatobi', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(326, 'Famuyiwa Abigael', 'Mathematics', '22', '51', '', '4J', '1st', '2016/2017'),
(327, 'Ogunlade Olabisi A.', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(328, 'Adejuwon Iorun', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(329, 'Okoroafor Chidima', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(330, 'Awoyele Samuel', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(331, 'Adebisi Jolaade Merit', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(332, 'Eme Destiny', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(333, 'Oyedokun Alfred', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(334, 'Ogundana Wilson Olukayode', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(335, 'Odewande Racheal', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(336, 'Afolabi Eohraim', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(337, 'Akinlade Tolulope M.', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(338, 'Adedokun Odunayo', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(339, 'Akintude Anuoluwa', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(340, 'Oyedeji Oluwafemi', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(341, 'Dada Oluwafeyikemi', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(342, 'Olatayo Mabel', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(343, 'Omidiji Ayomikun', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(344, 'Bamigboye Oluwatobi', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(345, 'Famuyiwa Abigael', 'Sciences', '27', '60', '', '4J', '1st', '2016/2017'),
(346, 'Ogunlade Olabisi A.', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(347, 'Adejuwon Iorun', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(348, 'Okoroafor Chidima', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(349, 'Awoyele Samuel', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(350, 'Adebisi Jolaade Merit', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(351, 'Eme Destiny', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(352, 'Oyedokun Alfred', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(353, 'Ogundana Wilson Olukayode', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(354, 'Odewande Racheal', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(355, 'Afolabi Eohraim', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(356, 'Akinlade Tolulope M.', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(357, 'Adedokun Odunayo', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(358, 'Akintude Anuoluwa', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(359, 'Oyedeji Oluwafemi', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(360, 'Dada Oluwafeyikemi', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(361, 'Olatayo Mabel', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(362, 'Omidiji Ayomikun', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(363, 'Bamigboye Oluwatobi', 'Music', '29', '66', '', '4J', '1st', '2016/2017'),
(364, 'Famuyiwa Abigael', 'Music', '29', '66', '', '4J', '1st', '2016/2017');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `name`) VALUES
(1, 'Social Studies'),
(2, 'Mathematics'),
(3, 'English'),
(4, 'Sciences'),
(5, 'Yoruba'),
(6, 'Agricultural Science'),
(7, 'B.K'),
(8, 'French Language'),
(9, 'Health Science'),
(10, 'Computer Science'),
(11, 'Music'),
(12, 'Fine Art'),
(13, 'Vocational');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'ACTIVE',
  `subject` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `password2` varchar(50) NOT NULL,
  `phone` text NOT NULL,
  `class` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `user_role`, `status`, `subject`, `name`, `student_name`, `password2`, `phone`, `class`) VALUES
(1, 'femi', '0146ba72b74b2b521a20bb00e0c41e3f', 'Teacher', 'ACTIVE', '', 'Mr. Femi Caleb', '0', 'oluwafemi1', '07056436142', '4K'),
(2, 'adeola', '82d99027f0be210b7ad4bd45d4679817', 'Parent', 'ACTIVE', '', 'Mr. Adeola Tobiloba', '0', '', '', ''),
(4, 'coluwadare', '82d99027f0be210b7ad4bd45d4679817', 'Parent', 'ACTIVE', '', 'Mr. Falemu Oluwafemi', 'ADELOOYE OMOBADEWA', 'oluwafemi', '', ''),
(5, 'bolagunlade@gmail.com', '82d99027f0be210b7ad4bd45d4679817', 'Parent', '', '', '', '', '', '', ''),
(6, 'lekamofe@yahoo.com', 'b59c67bf196a4758191e42f76670ceba', 'Parent', '', '', '', '', '', '', ''),
(9, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', 'ACTIVE', '', '', '', '', '', ''),
(10, 'posifasanya@gmail.com', '82d99027f0be210b7ad4bd45d4679817', 'Parent', '', '', 'Mr. Fasanya John Olaposi', '', 'oluwafemi', '', ''),
(11, '2', 'd41d8cd98f00b204e9800998ecf8427e', 'Parent', 'ACTIVE', '', 'Dr. & Dr. (Mrs.) Opadere', '', '', '', ''),
(12, 'wourlus@gmail.com', '82d99027f0be210b7ad4bd45d4679817', 'Parent', 'ACTIVE', '', 'Mr. Wolekemi Dada', 'Dada Oluwafeyikemi', 'oluwafemi', '07056436142', ''),
(13, 'folafemi2030@gmail.com', '82d99027f0be210b7ad4bd45d4679817', 'Parent', 'ACTIVE', '', 'Mr. & Mrs. Falana', '', 'oluwafemi', '08034635029, 08034650216', ''),
(20, 'femifalemu@gmail.com', 'oluwafemi', 'Parent', 'ACTIVE', '', 'Mr. & Mrs. Adebowale', 'Adebowale Ayisat', 'oluwafemi', '08162637500', ''),
(21, 'sunnyfexx@yahoo.com', 'oluwafemi', 'Parent', 'ACTIVE', '', 'Mr. & Mrs. Akindoyin', 'Akindoyin Iseoluwa', 'oluwafemi', '08182458806, 09029628941', ''),
(22, 'sunnyfexx@gmail.com', '82d99027f0be210b7ad4bd45d4679817', 'Parent', 'ACTIVE', '', 'Mr and Mrs Adekunle', 'Adekunle Favour', 'oluwafemi', '08037877772', ''),
(23, 'todox4real@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 'Parent', 'ACTIVE', '', 'Mr.& Mrs. Elubanji', 'Elubanji Omogbolahan', '', '08065007232', ''),
(24, '', 'd41d8cd98f00b204e9800998ecf8427e', 'Parent', 'ACTIVE', '', 'Dr. & Dr. (Mrs.) Opadere', '', '', '08171736565, 07062652992', ''),
(25, 'adegbajuvictor@yahoo.com', '5c8e82f0bdac09f37b0111c79f1fe0fa', 'Parent', 'ACTIVE', '', 'Mr and Mrs Adegbaju', 'Adegbaju Adedolapo', 'femi', '07062376306', ''),
(26, 'joshua@gmail.com', '7084f11e0c13cbea2c571f5f2b92eb77', 'Parent', 'ACTIVE', '', '', '', 'oluwa', '08067367726', ''),
(27, 'sunday@gmail.com', '0146ba72b74b2b521a20bb00e0c41e3f', 'Teacher', 'ACTIVE', '', 'sunday', '', 'oluwafemi1', '07062376306', '4K'),
(28, 'alabi', '1a679835db25eaa1b52bec711368f396', 'Teacher', 'ACTIVE', '', 'Alabi Paul', '', 'alabi', '08032453815', '4J'),
(29, 'eniita01@yahoo.co.uk', '3dbe00a167653a1aaee01d93e77e730e', 'Parent', 'ACTIVE', '', 'Mr. & Mrs. Olatayo', '', 'aaaaaaaa', '07035698070', ''),
(30, 'bisiyemo@yahoo.co.uk', '3dbe00a167653a1aaee01d93e77e730e', 'Teacher', 'ACTIVE', '', 'Mr Owolabi', '', 'aaaaaaaa', '08156299742', '4K'),
(31, 'ololade', 'd41d8cd98f00b204e9800998ecf8427e', 'Parent', 'ACTIVE', '', 'Mr and Mrs Ojo', 'Ojo Ololade', '', '08069307178', '5K');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inbox`
--
ALTER TABLE `inbox`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parent_access`
--
ALTER TABLE `parent_access`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recovery_pass`
--
ALTER TABLE `recovery_pass`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sent`
--
ALTER TABLE `sent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_record`
--
ALTER TABLE `student_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_result`
--
ALTER TABLE `student_result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `inbox`
--
ALTER TABLE `inbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT for table `parent_access`
--
ALTER TABLE `parent_access`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `recovery_pass`
--
ALTER TABLE `recovery_pass`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `sent`
--
ALTER TABLE `sent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `student_record`
--
ALTER TABLE `student_record`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=690;
--
-- AUTO_INCREMENT for table `student_result`
--
ALTER TABLE `student_result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=365;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
