$(document) .ready(function(){

	
$("#edit_record").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "edit_record.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#editRecordMsg2") .html(data);
			

		}

})


})	
})