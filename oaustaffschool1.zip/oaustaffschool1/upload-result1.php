<?php

include "connection.php";
if(!empty($_FILES['import_result']['name']))

{

	$file = $_FILES["import_result"]["name"];
	$file_tmp = $_FILES["import_result"]["tmp_name"];
	$output = "";
	$allowed_ext = array("csv");
	$extension = end(explode(".", $file));
	$date_added = date('Y-m-d');
	if(in_array($extension, $allowed_ext)){


		$file_data = fopen($file_tmp, "r");
		fgetcsv($file_data);
		while($row = fgetcsv($file_data)){


			$name = mysqli_real_escape_string($con, $row[1]);
			$test = mysqli_real_escape_string($con, $row[2]);
			$exam = mysqli_real_escape_string($con, $row[3]);
			$subject = mysqli_real_escape_string($con, $row[4]);
			$class = mysqli_real_escape_string($con, $row[5]);		


			$select = "SELECT * FROM student_result where student_name = '$name' and subject='$subject'
			and term='$_SESSION[term]' and session='$_SESSION[session]' and class='$class'";
			$result = mysqli_query($con, $select);
			$count = mysqli_num_rows($result);
			if ($count > 0){

				echo "<script type=\"text/javascript\">alert('$name result is already Added to the system');
			</script>";

			}
			
			else{
			$query = "INSERT INTO student_result (student_name,subject,test_score,exam_score,term,session,class) 
			VALUES('$name','$subject','$test','$exam','$_SESSION[term]','$_SESSION[session]','$class')";

			mysqli_query($con, $query);
		}
	}
			$no = 0;

				$select = "SELECT * FROM student_result";
				$result = mysqli_query($con, $select);

				$output .= '

					<table class="table">
					<tr>
						<th width="5%"> S/N  </th>
						<th width="15%">Name  </th>
						<th width="5%">Class  </th>
						<th width="5%"> Term </th>
						<th width="10%"> Session </th>
						<th width="15%">Subject  </th>
						<th width="15%">Test Score </th>
						<th width="15%">Exam Score  </th>
						<th width="15%">Total  </th>
						
					</tr>


				';

			while($row = mysqli_fetch_array($result)){

					$no++;
					$test = $row["test_score"];
					$exam = $row["exam_score"];
					$total = $test + $exam;
					$output .= '

						<tr>
							<td> '.$no.'</td>
							<td> '.$row["student_name"].'</td>
							<td> '.$row["class"].'</td>
							<td> '.$row["term"].'</td>
							<td> '.$row["session"].'</td>
							<td> '.$row["subject"].'</td>
							<td> '.$row["test_score"].'</td>
							<td> '.$row["exam_score"].'</td>
							<td> '.$total.'</td>
							
							


					';

			}
				$output .= "</table>";
				echo $output;

			}

		

			else{

				echo "Error1";
			}
			
		}

	else{

	echo "<script type=\"text/javascript\">alert('Please Select File');
			</script>";

}

?>