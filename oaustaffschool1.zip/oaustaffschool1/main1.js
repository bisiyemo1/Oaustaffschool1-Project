$(document) .ready(function(){

$("body").delegate(".deleteInbox","click",function(event){
	
	event.preventDefault();
	var pid = $(this).attr("delete_id");

	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {removeInboxMsg:1,removeId:pid},
			success : function(data){
			$("#responseMsg").html(data);
		


	}

})

})	
	

$("body").delegate(".deleteSent","click",function(event){
	event.preventDefault();
	var pid = $(this).attr("delete_id");

	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {removeSentMsg:1,removeId:pid},
			success : function(data){
			$("#responseMsg").html(data);
		
		


	}

})

})
$("body").delegate(".editId","click",function(event){
	event.preventDefault();
	var pid = $(this).attr("edit_id");

	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {editRecord:1,editId:pid},
			success : function(data){
			$("#editRecordMsg").html(data);
		
		


	}

})

})
$("body").delegate(".class","click",function(event){
event.preventDefault();
	var pid = $(this).attr("pid");
	var class1 = $("#class-"+pid).val();
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {AllDetails:1,Class:class1},
			success : function(data){
			$("#AllDetails").html(data);
			}
		})
	
})


})