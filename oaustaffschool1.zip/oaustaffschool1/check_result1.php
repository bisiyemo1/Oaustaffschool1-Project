<?php

include "connection.php";

$subject = $_POST['subject'];


if(!$subject){


	echo  "<script type=\"text/javascript\">alert('Please Select a Subject');
						</script>";

}else{

		$sql = "SELECT * FROM student_result where subject='$subject' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
		$run_sql = mysqli_query($con, $sql);
		$count = mysqli_num_rows($run_sql);

		if($count == 0 ){

			echo  "<script type=\"text/javascript\">alert('Result Not Found in the System');
						</script>";

		}else{

			$no = 0;

		echo '

					<table class="table">
					<tr>
						<th width="5%"> S/N  </th>
						<th width="15%">Name  </th>
						<th width="5%">Class  </th>
						<th width="5%"> Term </th>
						<th width="10%"> Session </th>
						<th width="15%">Subject  </th>
						<th width="15%">Test Score </th>
						<th width="15%">Exam Score  </th>
						<th width="15%">Total  </th>
						
					</tr>


				';

			while($row = mysqli_fetch_array($run_sql)){

					$no++;
					$test = $row["test_score"];
					$exam = $row["exam_score"];
					$total = $test + $exam;
					echo '

						<tr>
							<td> '.$no.'</td>
							<td> '.$row["student_name"].'</td>
							<td> '.$row["class"].'</td>
							<td> '.$row["term"].'</td>
							<td> '.$row["session"].'</td>
							<td> '.$row["subject"].'</td>
							<td> '.$row["test_score"].'</td>
							<td> '.$row["exam_score"].'</td>
							<td> '.$total.'</td>
							
							


					';

	}

}

}






?>