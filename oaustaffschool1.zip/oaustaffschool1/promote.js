$(document) .ready(function(){
$("#promote_to").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "promote1.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#PromoteMsg") .html(data);
			

		}

})
})


})