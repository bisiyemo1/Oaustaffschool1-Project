$(document) .ready(function(){
$("#edit_result").click(function(event){
	
	event.preventDefault();
		$.ajax({
			url : "edit_result1.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#EditResult") .html(data);
			

		}

})
})
$("body").delegate(".result","click",function(event){
	event.preventDefault();
	
	var pid = $(this).attr("result_id");
	var test = $("#test-"+pid).val();
	var exam = $("#exam-"+pid).val();
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {ResultMessage:1,resultId:pid,test:test,exam:exam},
			success : function(data){
			$("#EditResult").html(data);
			


	}

})

})
})