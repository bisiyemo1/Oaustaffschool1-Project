<?php
require_once "connection.php";
$msg = "";
$error = "";
if(isset($_POST['register'])){

  $username = $_POST['username'];
  $password   = $_POST['password'];
  $c_password   = $_POST['c_password'];
  $password2 = $_POST['password'];
  $id = $_POST['id'];


  if((!$password) || (!$username)){

    $error =  "Please fill empty fields";

}
elseif($c_password != $password){

    $error=   "Your Password do not match";

}else{
        

      $sql = "SELECT * FROM user WHERE username='$username'"; 
      $run_sql = mysqli_query($con,$sql);
      $login_check = mysqli_num_rows($run_sql);
        // If login check number is greater than 0 (meaning they do exist and are activated)
    if($login_check > 0){ 

      $password = md5($password);

      $user_role = "Parent";

      while($row=mysqli_fetch_array($run_sql)){

        $parent_name = $row["name"];
        $student_name = $row["student_name"];
        $phone = $row["phone"];

       
      }
      $update = "UPDATE user SET password='$password', password2='$password2' WHERE username='$username' ";
      if(mysqli_query($con,$update)){


        echo " <script type=\"text/javascript\">alert('Password Successfully Changed');
            window.location='change-password.php?details=$id'</script>";
      }

    }
    else{

      $msg = "Operation NOT Successful";

    }

}

}
?>