<?php

include "connection.php";
$msg = "";
if(isset($_POST['edit_record'])){

$parent_name = $_POST['p_name'];
$id = $_POST['id'];
$username = $_POST['email'];
$student_name = $_POST['stu_name'];
$class = $_POST['class'];
$num = $_POST['number'];
$phone = $_POST['phone'];
$sex = $_POST['sex'];
$user_role = "Parent";
$status = $_POST['status'];
$date = date("Y-m-d");

if((!$parent_name)  || (!$username) || (!$student_name) || (!$class) || (!$sex) || (!$phone)){


	echo  "<script type=\"text/javascript\">alert('Please fill all the field');
						window.location='edit-record.php?details=$id'</script>";

			}
						
	
	else{


	$sql = "SELECT * FROM user where username= '$username' or student_name = '$student_name'";
	$run_sql = mysqli_query($con, $sql);
	$count = mysqli_num_rows($run_sql);

	if($count < 1){
		$password = $_POST['password'];
		$password2 = $_POST['password'];

		$password = md5($password);
		mysqli_query($con, "INSERT INTO user(username,password,user_role,status,name,student_name,phone,password2,class)
				 values('$username','$password','Parent','ACTIVE','$parent_name','$student_name','$phone','$password2','$class')");
		mysqli_query($con, "UPDATE student_record set email='$username' where id='$id'");
		echo  "<script type=\"text/javascript\">alert('$parent_name Details Registered Successfully')
						window.location='edit-record.php?details=$id'</script>";

	}if($count > $num){

			echo  "<script type=\"text/javascript\">alert('$username already exist in the system')
						window.location='edit-record.php?details=$id'</script>";

	}else{

			
			$sql = "UPDATE student_record set student_name='$student_name',sex='$sex',class='$class',email='$username',phone='$phone',
				parent_name='$parent_name',date_added='$date',status='$status' where id='$id' ";
				if(mysqli_query($con, $sql)){

					

				mysqli_query($con, "UPDATE user set username='$username',status='$status',name='$parent_name',
					student_name='$student_name',phone='$phone',class='$class' where username='$username' ");

				echo  "<script type=\"text/javascript\">alert('$parent_name Details Edited Successfully');
						window.location='edit-record.php?details=$id'</script>";


			}else{


				echo  "<script type=\"text/javascript\">alert('$parent_name Details NOT Successfully Edited');
						</script>";

			}



	}

}

}

?>