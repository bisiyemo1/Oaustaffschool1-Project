<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OAU STAFF SCHOOL</title>
    <link href="home/css/bootstrap.min.css" rel="stylesheet">
	<link href="CustomStyleHome.css" rel="stylesheet" />

	<style type="text/css">
		
		body{ position: relative; }

	</style>

  </head>

  <body data-spy="scroll" data-target="#mainNavbar" data-offset="10">

					
					<!--Code for navigation bar and Header-->
					
					<nav id="mainNavbar" >  

					<!--Code for header only-->
							
						
							<div class="row">
								<div class="col-xs-12">

									<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
										<div class="panel-heading">
										
											<div id="customDiv2">
												<img class="img-responsive" src="images/schoollogo.jpg">
											</div>
										
										
											<h3 class="panel-title">OBAFEMI AWOLOWO UNIVERSITY STAFF SCHOOL<h3>
											
										</div>
							
									</div>
								</div>
							</div>
				
									
					<!--Code for Navigation bar using breadcrumb-->
														
									<div class="row">
										<div class="col-xs-12">
													<!--NOTE: The forward slash "/" of the breadcrumb is changed to vertical slash"|". The background color or other things, can also be changed to your desire color(yellow)-->
							
												<ol class="breadcrumb">
														<li><a href="index.php">Home</a></li>
														<li class="active"><a href="about.php">About</a></li>
														<li><a href="login.php">Portal</a></li>
												</ol>

										</div>
									</div>
															
					</nav> 

		
	<!--Code For jumbotron that contain vision, mission statement, and aim. -->
			<div class="container">
				<div class="jumbotron">
					<p class="btn btn-lg btn-primary"><strong>Vission</strong></p>			
					<p>the provision of qualitative education for the children of the rich and the less privileged.</p>

					<p class="btn btn-lg btn-primary"><strong>Mission Statement</strong></p>
					 <p>Our mission is to continue to be a force to reckoned with in this 
					environment as it fulfills its mandate of ensuring the provision of qualitative 
					education for the children of the rich and the less privileged.</p>

					<p class="btn btn-lg btn-primary"><strong>Our Aim</strong></p>
					<p>Our aim is to lay a formidable foundation of a life-long qualitative 
					education for the children of the rich and the less privileged giving the children
					confidence and respect that will overcome all distinctions of race, class, colour and creed.</p>
					                                                                                                  
				</div>
	
			</div>


<!--Code For column that contain CEO PIX -->
			<div class="container">
				<br /><br />
				<div class="row">
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							 <img class="img-responsive" src="images/library.jpg"/> <h3>LIBRARY</h3> A school library plays a great role in the life of a student. It is the store house of knowledge. Hence, it exhibits positive impact on the academic achievement of the student.
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<img class="img-responsive" src="images/compLab.jpg"/> <h3>COMPUTER LAB</h3> Computer have revolutionized much of modern life, either directly or indirectly, and learning how to use them in school is extremely important. Children learn it at early stage.
							
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="customDiv1">
							<img class="img-responsive" src="images/cafetaria.jpg"/> <h3>SCHOOL CAFETERIA</h3> We all know that healthy food is important. In orther to facilitate children to make more healthy food choices and to develop healthy eating habits, hence school cafetaria is crucial.
						</div>
					</div>
				</div>
			</div>




















			
	<!-- For footer -->

		<div id="footer"> 

			<div id="copyright">
				&copy; Copyright 2018 by OAU STAFF SCHOOL. All right reserved.
			</div>
	
			<div id="sociallink">
		
				<a href="http://www.gmail.com"><img src="images/gmail.jpg" /></a>
				<a href="http://www.yahoomail.com"><img src="images/email.jpg" /></a>
				<a href="http://www.youtube.com"><img src="images/youtube.jpg" /></a>
				<a href="http://www.twitter.com"><img src="images/twitter.jpg" /></a>
				<a href="http://www.facebook.com"><img src="images/facebook.jpg" /></a>
			</div>
	
		</div>






















			<script src="js/jquery.min.js"></script>
  		<script src="js/bootstrap.min.js"></script>


    </body>
</html>