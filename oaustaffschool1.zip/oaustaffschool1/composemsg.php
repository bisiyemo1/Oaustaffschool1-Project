<?php

include "connection.php";
$_SESSION['sms'] = "";
if(isset($_POST['composemsg'])){

$name = $_POST['name'];
$class = $_POST['class'];
$message = $_POST['message'];
$user_role = $_SESSION['user_role'];
$date = date("Y-m-d h:i:sa");
$title = "Alert";
if((!$name)  || (!$message)){


	echo " <script type=\"text/javascript\">alert('Field cannot be empty');
						window.location='messages.php'</script>";
}
	
	else{




		$sql2 = "SELECT * FROM user where name='$name'" ;
							$run_sql = mysqli_query($con,$sql2);
							$count = mysqli_num_rows($run_sql);

							if($count == 0 ){

			echo  "<script type=\"text/javascript\">alert('$name has not been registered, therefore, he cannot receive SMS Alert');
						window.location='messages.php'</script>";

				}else {
							while($row=mysqli_fetch_array($run_sql)){
	
									$student_name = $row['student_name'];
									
									$receiver = $row['name'];
									$phone_no = $row['phone'];

						}

				if($_SESSION['user_role'] == 'Parent'){

			$sql1 = "SELECT * FROM user where class='$class' " ;
							$run_sql = mysqli_query($con,$sql1);
							while($row=mysqli_fetch_array($run_sql)){
	
									$receiver = $row['name'];
									$phone_no = $row['phone'];

						}

					}

				

	$sql = "INSERT INTO inbox (receiver,title,message,user_role,msg_date,sender,status,student_name,class) values ('$receiver','$title','$message','$user_role','$date','$_SESSION[name]','inbox','$student_name','$class')";
	if(mysqli_query($con,$sql)){

		mysqli_query($con, "INSERT INTO sent (receiver,title,message,user_role,msg_date,sender,status) values ('$receiver','$title','$message','$user_role','$date','$_SESSION[name]','sent')");

		$sms = '<iframe src="http://api.smartsmssolutions.com/smsapi.php?username=oaustaffschool&password=oaustaffschool&sender=OauStaffSch&recipient='.$phone_no.'&message=Dear '.$receiver.', '.$student_name.' '.$message.'. Thanks"</iframe>';

		echo "<center>

				

				<div style='color:green;'> Message Sent successfuly to $receiver  </div>
				<a href='messages.php'>Return to Message</a>
				<div>$sms </div>
				</center>";

		echo " <script type=\"text/javascript\">alert('Message sent successfuly to $receiver');
						window.location='messages.php'</script>";


		

		


		

		}
	}

}

}

?>
