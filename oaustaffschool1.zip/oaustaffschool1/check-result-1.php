<?php

					require_once "connection.php";
						
							

					if(isset($_POST['viewResult1'])){
							
							echo "<center>
									<table class='table' style='width:50%;'>

									<thead style='background-color:green; color:white;'>
												<th>Subject</th>
												<th>Test Score</th>
												<th>Exam Score</th>
												<th>Total Score</th>
									</thead>
									";



								echo "<tr><td>English</td>";

								$sql = "SELECT * FROM student_result where subject='English' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}
									
									echo "<tr><td>Social Studies</td>";

								$sql = "SELECT * FROM student_result where subject='Social Studies' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}

									echo "<tr><td>Mathematics</td>";

								$sql = "SELECT * FROM student_result where subject='Mathematics' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;


									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}

									$subject = "Sciences";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}	

									$subject = "Yoruba";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}
									$subject = "Agricultural Science";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}

									$subject = "French Language";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}

									$subject = "Computer Science";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}
									$subject = "Health Sciences";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}
									$subject = "Fine Art";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}
									$subject = "Vocational";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}
									$subject = "Music";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}
									$subject = "B.K";
									echo "<tr><td>$subject</td>";

								$sql = "SELECT * FROM student_result where subject='$subject' and student_name='$_SESSION[student_name]' and term='$_SESSION[term]'
							and session = '$_SESSION[session]' and class='$_SESSION[class]' ";
									$run_sql_1 = mysqli_query($con, $sql);
									while($row=mysqli_fetch_array($run_sql_1)){


										$test = $row['test_score'];
										$exam = $row['exam_score'];
										$total = $test + $exam;

									echo "<td>$test</td>
									     <td>$exam</td>
									     <td>$total</td>

									</tr>";	
									}																		
		
		


						

				}	




?>