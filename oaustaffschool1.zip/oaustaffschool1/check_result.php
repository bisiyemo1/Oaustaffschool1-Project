<?php
require_once("connection.php");
if($_SESSION['user_role'] != "Teacher")
{

header("location: logout.php");
}
?>
<!DOCTYPE html>
<html lang="en">  
<head>
    <meta charset="utf-8">
    <title>Generate Report - OAU STAFF SCHOOL</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    
    <link href="css/style.css" rel="stylesheet">
    
    
    <link href="js/guidely/guidely.css" rel="stylesheet"> 
    <link href="css/pages/plans.css" rel="stylesheet"> 
    <link href="js/jquery-ui.css" rel="stylesheet"> 
    <link href="css/pages/signin.css" rel="stylesheet"> 
    <link href="css/pages/dashboard.css" rel="stylesheet"> 

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.js"></script>
        <script src="main.js"></script>
        <script src="teacher.js"></script>
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<link href="CustomStyleHome.css" rel="stylesheet" />
  </head>

<body>

					<!--Code for navigation bar and Header-->
					
					<nav id="mainNavbar" >  

					<!--Code for header only-->
							
						
							<div class="row">
								<div class="col-xs-12">

									<div class="panel panel-primary"> <!--Panel-default, panel-info, -->
										<div class="panel-heading">
										
											<div id="customDiv2">
												<img class="img-responsive" src="images/schoollogo.jpg">
											</div>
										
										
											<h3 class="panel-title">OBAFEMI AWOLOWO UNIVERSITY STAFF SCHOOL<h3>
											
										</div>
							
									</div>
								</div>
							</div>
				
									
					<!--Code for Navigation bar using breadcrumb-->
														
									<div class="row">
										<div class="col-xs-12">
													<!--NOTE: The forward slash "/" of the breadcrumb is changed to vertical slash"|". The background color or other things, can also be changed to your desire color(yellow)-->
							
												<ol class="breadcrumb">
														<li class="active"><a href="index.php">Home</a></li>
														<li class="active">/<a href="about.php">About</a></li>
														<li class="active">/<a href="login.php">Portal</a></li>
														 <ul class="nav pull-right active">	
														     <li class="">						
															     <a href="logout.php" class="">
																     Logout
													       		</a>
														     </li>
													    </ul>
												</ol>

										</div>
									</div>
															
					</nav> 

    
<?php include "menu.php";   ?>
    
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	
	      <div class="row">	 

	      	<div class="span6">
	      		
	      		<div class="widget">
	      			
	      			<div class="widget-content">
	      				
			      		<h1>Check Results</h1>
			      		
			      		<p></p>	
			      		
		      		</div> <!-- /widget-content -->
		      		
	      		</div> <!-- /widget -->
	      		
      		</div> <!-- /span6 -->
      		 	
	      	
	      	<div class="span6">
	      		
	      		<div id="target-2" class="widget">
	      			
	      			<div class="widget-content">
	      				
			      		<h3 id=""></h3>
			      		
			      		<p></p>	
			      		
		      		</div> <!-- /widget-content -->
		      		
	      		</div> <!-- /widget -->
	      		
      		</div> <!-- /span6 -->   
      		</div>  	
	     

<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	
	      <div class="row">
	      	
	      	<div class="span12">
	      		<center>
	      		<div class="widget">
						
					<div class="widget-header">
						<i class="icon-th-large"></i>
						<h3>Check Result</h3>  
					</div> <!-- /widget-header -->
					<div>
						<br>
						<div style="color:red;" id="DelResult"></div>
						<hr>
						<form action="#" method="post" id="myform" enctype="multipart/form-data">
						<div class="login-fields">		
				<div class="field">
					<label for="firstname">Term</label>
					<input type="text" id="username" name="" placeholder="<?php echo $_SESSION['term']; ?> Term" class="username" disabled/>
				</div> <!-- /field -->
				<div class="field">
					<label for="firstname">Session</label>
					<input type="text" id="username" name="" placeholder="<?php echo $_SESSION['session']; ?>" class="username" disabled/>
				</div> <!-- /field -->
				<div class="field">
					<label for="firstname">Class</label>
					<input type="text" id="username" name="" placeholder="<?php echo $_SESSION['class']; ?>" class="username" disabled/>
				</div> <!-- /field -->
			
				<div>
					<label>Select Student Name</label>
					<select name="subject" style="width:28%;">
						<option value="">Select Subject</option>
					<?php  

					//this section display the data in the database into the input box in the forms below

							

								$sql = "SELECT * FROM subject";
								$run_sql = mysqli_query($con,$sql);

								while($row=mysqli_fetch_array($run_sql)){
						
								$name = $row["name"];
								

								

						echo "<option value='$name'>$name</option>";

						}

			 		?>
					 	


				
					</select>
				</div>
				
				<input type="submit" style="width:100%;" class="button btn btn-success btn-large" name="check_result" id="check_result" value="Check Results">
				
						</center>
					</div>
					<div>
						
					</div>
						<div id="CheckResult"> </div>
						
									
								</div>
								</div> <!-- /widget-content -->
						
								</div> <!-- /widget -->
										
						    </div> <!-- /span12 -->     	
					      	
					      	
					      </div> <!-- /row -->
					
					    </div> <!-- /container -->
					    
					</div> <!-- /main-inner -->
				    
				</div> <!-- /main -->
    	      	</div>

	      </div>
	  </div>

<div class="extra">

	<div class="extra-inner">

		<div class="container">


		</div> <!-- /container -->

	</div> <!-- /extra-inner -->

</div> <!-- /extra -->  
<div class="footer">
	
	<div class="footer-inner">
		
		<div class="container">
			
			<div class="row">
				
    			<div class="span12">
    				&copy; <?php echo date('Y');   ?><a href="#">  Obafemi Awolowo University Staff School</a>.
    			</div> <!-- /span12 -->
    			
    		</div> <!-- /row -->
    		
		</div> <!-- /container -->
		
	</div> <!-- /footer-inner -->
	
</div> <!-- /footer -->
    

<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.7.2.min.js"></script>

<script src="js/bootstrap.js"></script>
<script src="js/base.js"></script>

<script src="js/guidely/guidely.min.js"></script>

<script>



</script>
  </body>

</html>
