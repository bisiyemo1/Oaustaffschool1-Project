<?php

include "connection.php";

$promote_to = $_POST['to'];
$promote_from = $_POST['from'];


if((!$promote_from)  || (!$promote_to)){

	echo  "<script type=\"text/javascript\">alert('Please Choose Class in the List');
						</script>";

	
}
	
	else{

				$select = "SELECT * FROM student_record where class='$promote_from' ";
				$result = mysqli_query($con, $select);

				$count = mysqli_num_rows($result);

					if($count == 0 ){

		
				echo "<script type=\"text/javascript\">alert('No Class $promote_from found in the system');
						</script>";				

				}else{

			$sql = "UPDATE student_record SET class='$promote_to' WHERE class = '$promote_from'";

				if(mysqli_query($con,$sql)){


				echo  "<script type=\"text/javascript\">alert('Students of Class $promote_from has been successfully promoted to $promote_to');
						</script>";

			}else{

					echo  "<script type=\"text/javascript\">alert('Operation Not Successful');
						</script>";

			}

}
}

?>