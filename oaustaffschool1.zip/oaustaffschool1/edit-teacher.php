<?php
require_once("edit_teacher.php");
if($_SESSION['user_role'] != "Administrator")
{

header("location: logout.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  
 <head>
    <meta charset="utf-8">
    <title>Add Parent Account - OAU STAFF SCHOOL</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />

<link href="css/font-awesome.css" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
    
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/pages/signin.css" rel="stylesheet" type="text/css">
<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.js"></script>
        <script src="main.js"></script>
</head>

<body>
	
	<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<a class="brand" href="index.html">
				Obafemi Awolowo University Staff School				
			</a>		
			
			<div class="nav-collapse">
				<ul class="nav pull-right">
					<li class="">						
						<a href="administrator.php" class="">
							Back to Dashboard
						</a>
						
					</li>
					<li class="">						
						<a href="logout.php" class="">
							<i class="icon-chevron-left"></i>
							Logout
						</a>
						
					</li>
				</ul>
				
			</div><!--/.nav-collapse -->	
	
		</div> <!-- /container -->
		

	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->


<?php include "menu.php";   ?>
<div class="account-container register">
	
	<div class="content clearfix" >
		<?php echo $msg;  ?>
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" id="myform" enctype="multipart/form-data">
					<?php
					if(isset($_GET['details'])){

							$pid = $_GET['details'];



							$sql = "SELECT * FROM user where id= '$pid'";
							$run_sql = mysqli_query($con,$sql);

							while($row=mysqli_fetch_array($run_sql)){
	
							
							$id = $row['id'];
							$name = $row['name'];
							
							$class = $row['class'];
							$status= $row['status'];
							$username= $row['username'];
							$phone= $row['phone'];
							$password= $row['password2'];
							
							$comma = " 's ";


					echo '		<center>
							<br>
							<br>
			
		
			<h3 style="color:red;">You are Editing '.$name.''.$comma.' Details</h3>			
			
			<div class="login-fields">
				<div class="field">
					<label for="firstname">Parent Name</label>
					<input type="text" id="t_name" name="t_name" placeholder="Parent Name" value="'.$name.'" class="username" />
				</div> 
				<div class="field">
					<label for="firstname">Class</label>
					<input type="text" id="username" name="class" placeholder="Class" value="'.$class.'" class="username" />
				</div>
			<div class="field">
					<label for="firstname">Email</label>
					<input type="text" id="username" name="username" placeholder="Email" value="'.$username.'" class="username" disabled/>
				</div>
				<div class="field">
					<label for="firstname">Password</label>
					<input type="text" id="password" name="password" placeholder="Password" value="'.$password.'" class="username" />
				</div>  
				<input type="hidden" name="id" value="'.$id.'">
				
				<div class="field">
					<select class="username" name="status" style="width:100%;">
						<option value="'.$status.'">'.$status.'</option>
					<option value="ACTIVE">ACTIVE</option>	
					<option value="INACTIVE">INACTIVE</option>
					</select>
				</div>
								
				
				<div class="field">
					<label for="phone">Phone Number</label>	
					<input type="text" id="phone" name="phone" placeholder="Phone Number" value="'.$phone.'" class="login" />
				</div> 
				';

				 
				
			echo'
			<input type="submit" style="width:30%; margin-right:20px;" class="button btn btn-success btn-large" name="edit_teacher" id="edit_teacher" value="Edit">
				
			</div> 

					</div>
				
			</div></form>
		
							';

							
						}

					}
				
		
		?>
		</center>

		<br>
		<br>
	</div> <!-- /content -->
	
</div> <!-- /account-container -->
 <div class="login-extra">
	Return to  <a href="all_teacher.php">View All Teacher</a>
</div> <!-- /login-extra -->
  
<script type="text/javascript">
 
</script>
<!-- Text Under Box -->
<div class="footer">
	
	<div class="footer-inner">
		
		<div class="container">
			
			<div class="row">
				
    			<div class="span12">
    				&copy; <?php echo date('Y');   ?><a href="#">  Obafemi Awolowo University Staff School</a>.
    			</div> <!-- /span12 -->
    			
    		</div> <!-- /row -->
    		
		</div> <!-- /container -->
		
	</div> <!-- /footer-inner -->
	
</div> <!-- /footer -->
 

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>

<script src="js/signin.js"></script>

</body>

 </html>
