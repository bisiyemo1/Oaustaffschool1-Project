$ (document) .ready(function(){

$("#myupload").on('submit', function(event){
	event.preventDefault();
		$.ajax({

			url : "upload_student_record.php",
			method: "POST",
			data   :  new FormData(this),
			contentType:false,
			cache:false,
			processData: false,
			success : function(data){

			if(data == "Error1"){

				alert("Invalid File Input");

			}else if(data == "Error2"){

				alert("please select file");
			}
			else if(data == "Error3"){

				alert("Student is Already Added");
			}
			else{
				$("#UploadMsg") .html(data);

			}
			


		}

	})

})

$("#resultupload").on('submit', function(event){
	event.preventDefault();
		$.ajax({

			url : "upload-result1.php",
			method: "POST",
			data   :  new FormData(this),
			contentType:false,
			cache:false,
			processData: false,
			success : function(data){
			$("#UploadResultMsg") .html(data);

		}	

	})

})


view_student();
function view_student(){
		$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {viewStudent:1},
			success : function(data){
			$("#ViewStudentMsg").html(data);
			}
		})
	}

$("body").delegate(".update","click",function(event){

	event.preventDefault();
	
	var pid = $(this).attr("update_id");
	var id = $("#id-"+pid).val();
	var status = $("#status-"+pid).val();
	
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {updateStudentStatus:1,updateId:pid,id:id,status:status},
			success : function(data){
			$("#updateStudentMsg").html(data);
			view_student();


	}

})

})
$("body").delegate(".remove","click",function(event){

	event.preventDefault();
	var pid = $(this).attr("remove_id");
	
	
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {removeStudent:1,removeId:pid},
			success : function(data){
			$("#removeStudentMsg").html(data);
			view_student();


	}

})

})


$("#parent_access").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "p-access.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#parentAccessMsg") .html(data);
			

		}

})


})

view_student_details();
function view_student_details(){
		$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {viewStudentDetail:1},
			success : function(data){
			$("#ViewStudentDetailMsg").html(data);
			}
		})
	}



	compose();
	function compose(){
		$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {Compose:1},
			success : function(data){
			$("#composeMsg").html(data);
			}
		})
	}


$("body").delegate(".deleteSent","click",function(event){
	
	event.preventDefault();
	var pid = $(this).attr("delete_id");

	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {removeSentMsg:1,removeId:pid},
			success : function(data){
			$("#responseMsg").html(data);
			compose();
		


	}

})

})


$("body").delegate(".compose","click",function(event){
	event.preventDefault();
	
	var pid = $(this).attr("compose_id");
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {ComposeMessage:1,composeId:pid},
			success : function(data){
			$("#responseMsg").html(data);
			compose();


	}

})

})


$("body").delegate(".sent","click",function(event){
	
	event.preventDefault();
	var pid = $(this).attr("sent_id");
	$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {SentMessage:1,sentId:pid},
			success : function(data){
			$("#responseMsg").html(data);
			compose();


	}

})

})
$("#compose1").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "composemsg.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#composeMsg") .html(data);
			

		}

})


})

$("#teacher-access").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "t-access.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#t-access") .html(data);
			

		}

})


})
$("#direct_result").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "direct_upload.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#ResultMsg") .html(data);
			

		}

})


})
$("#c_result").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "c_result.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#ResultMsg") .html(data);
			

		}

})


})
$("#generate").click(function(event){
	event.preventDefault();
		$.ajax({
			url : "generate1.php",
			method: "POST",
			data   :  $("form").serialize(),
			success : function(data){
			$("#GenerateMsg") .html(data);
			

		}

})


})


	teacher_info();
function teacher_info(){
		$.ajax({
			url : "connection.php",
			method: "POST",
			data   :  {viewTeacherDetail:1},
			success : function(data){
			$("#ViewGenerateMsg").html(data);
			}
		})
	}


	view_result();
function view_result(){
		$.ajax({
			url : "check-result-1.php",
			method: "POST",
			data   :  {viewResult1:1},
			success : function(data){
			$("#ViewResultMsg").html(data);
			}
		})
	}


})