<?php

include "connection.php";
if(!empty($_FILES['import_student']['name']))

{

	$file = $_FILES["import_student"]["name"];
	$file_tmp = $_FILES["import_student"]["tmp_name"];
	$output = "";
	$allowed_ext = array("csv");
	$extension = end(explode(".", $file));
	$date_added = date('Y-m-d');
	if(in_array($extension, $allowed_ext)){


		$file_data = fopen($file_tmp, "r");
		fgetcsv($file_data);
		while($row = fgetcsv($file_data)){


			$p_name = mysqli_real_escape_string($con, $row[1]);
			$student_name = mysqli_real_escape_string($con, $row[2]);
			$phone = mysqli_real_escape_string($con, $row[3]);
			$class = mysqli_real_escape_string($con, $row[4]);
			$email = mysqli_real_escape_string($con, $row[5]);
			$sex = mysqli_real_escape_string($con, $row[6]);
			$status = "ACTIVE";


			$select = "SELECT * FROM student_record where student_name = '$student_name'";
			$result = mysqli_query($con, $select);
			$count = mysqli_num_rows($result);
			if ($count > 0){

				echo "<script type=\"text/javascript\">alert('$student_name is already Added to the class');
			</script>";

			}
			
			else{
			$query = "INSERT INTO student_record (student_name,sex,class,status,date_added,parent_name,phone,email) VALUES('$student_name','$sex','$class','$status','$date_added','$p_name','$phone','$email')";

			mysqli_query($con, $query);
		}
	}
			$no = 0;

				$select = "SELECT * FROM student_record where student_name='$student_name'";
				$result = mysqli_query($con, $select);

				$output .= '

					<table class="table">
					<tr>
						<th width="5%"> S/N  </th>
						<th width="35%">Name  </th>
						<th width="5%">Sex  </th>
						<th width="5%">Class  </th>
						<th width="10%">Status  </th>
						<th width="20%">Parent Name  </th>
						<th width="15%">Date Added  </th>
					</tr>


				';

			while($row = mysqli_fetch_array($result)){

					$no++;
					$output .= '

						<tr>
							<td> '.$no.'</td>
							<td> '.$row["student_name"].'</td>
							<td> '.$row["sex"].'</td>
							<td> '.$row["class"].'</td>
							<td> '.$row["status"].'</td>
							<td> '.$row["parent_name"].'</td>
							<td> '.$row["date_added"].'</td>
							


					';

			}
				$output .= "</table>";
				echo $output;

			}

		

			else{

				echo "Error1";
			}
			
		}

	else{

	echo 'Error2';
}

?>